import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Observable";
import { Http, Response, Headers } from "@angular/http";
import { Promotion } from "../models/promation";

@Injectable()
export class PromotionsService {
  /**
   * header
   */
  headers = new Headers();
  /**
   * @constructor
   * @param {Http} http
   */
  constructor(private http: Http) {
    this.headers.append("Content-Type", "application/json");
  }

  /**
   * get Promotion by category
   *
   * @param {string} category The category promotions
   * @returns {Observable<Promotion[]>} The array promotions observable.
   */
  public getPromationByCategory(category: string): Observable<Promotion[]> {
    return this.http.get("http://localhost:3000/promotions?promotionCategory=" + category).map((res: Response) => {
      const promotions = res.json();
      return promotions;
    });
  }
  /**
     * get Promotion by category
     *
     * @param {string} category The category promotions
     * @returns {Observable<any>} The array promotions observable.
     */
  public postPromation(promotion: any): Observable<any> {
    return this.http.post("http://localhost:3000/promotions", promotion, { "headers": this.headers }).map((res: Response) => {
      return res;
    });
  }

  /**
   * get number Promotion by category
   *
   * @param {string} category The category promotions
   * @returns {Observable<number>} The number promotions observable.
   */
  public getNumberPromationByCategory(category: string): Observable<number> {
    return this.http.get("http://localhost:3000/promotions?promotionCategory=" + category).map((res: Response) => {
      const promotions = res.json();
      return promotions.length;
    });
  }


  /**
   * get Promotion by category Admin
   *
   * @param {string} category The category promotions
   * @returns {Observable<Promotion[]>} The array promotions observable.
   */
  public getAdminPromationByCategory(category: string): Observable<Promotion[]> {
    return this.http.get("http://localhost:3000/adminPromotions?promotionCategory=" + category).map((res: Response) => {
      const promotions = res.json();
      return promotions;
    });
  }


  /**
   * get Promotion by id Admin
   *
   * @param {string} id The id promotions
   * @returns {Observable<Promotion>} The array promotions observable.
   */
  public getAdminPromationById(id: string): Observable<Promotion> {
    return this.http.get("http://localhost:3000/adminPromotions?id=" + id).map((res: Response) => {
      const promotions = res.json();
      return promotions;
    });
  }


  /**
  * get number Promotion by category
  *
  * @param {string} category The category promotions
  * @returns {Observable<number>} The number promotions observable.
  */
  public getNumberPromationByCategoryAdmin(category: string): Observable<number> {
    return this.http.get("http://localhost:3000/adminPromotions?promotionCategory=" + category).map((res: Response) => {
      const promotions = res.json();
      return promotions.length;
    });
  }


  /**
  * Search Promotion
  *
  * @param {object} query The query search
  * @returns {Observable<Promotion[]>} The array promotions observable.
  */
  // filter data table
  search(query: any): Observable<Promotion[]> {
    return this.http.get("http://localhost:3000/promotions").map((res: Response) => {
      let promotions = res.json();
      if (promotions) {
        // get by category
        if (query.promotionCategory && query.promotionCategory !== "") {
          promotions = promotions.filter(item => item.promotionCategory === query.promotionCategory)
        }
        // search promotion Name
        if (query.promotionName && query.promotionName !== "") {
          promotions = promotions.filter(item => item.promotionName.toLowerCase().indexOf(query.promotionName.toLowerCase()) !== -1);
        }

        // search by promotion name ,merchant name, category
        if (query.searchName && query.searchName !== "") {
          promotions = promotions.filter(item => {
            if (item.promotionMerchant.toLowerCase().indexOf(query.searchName.toLowerCase()) !== -1) {
              return true;
            }
            return false;
          });
        }
        // search promotion start Date
        if (query.promotionStartDate && query.promotionStartDate !== "") {
          const startDate = new Date(query.promotionStartDate);
          promotions = promotions.filter(item => {
            const dateItem = new Date(item.promotionStartDate);
            if (startDate <= dateItem) {
              return true;
            }
            return false;
          });
        }
        // search promotion end Date
        if (query.promotionEndDate && query.promotionEndDate !== "") {
          const endDate = new Date(query.promotionEndDate);
          promotions = promotions.filter(item => {
            const dateItem = new Date(item.promotionStartDate);
            if (endDate >= dateItem) {
              return true;
            }
            return false;
          });
        }
        // search promotion status
        if (query.promotionStatus && query.promotionStatus !== "" && query.promotionStatus !== "All") {
          promotions = promotions.filter(item => item.promotionStatus.toLowerCase() === query.promotionStatus.toLowerCase());
        }
        return promotions;
      }
    })
  }

  // filter data table
  /**
  * Search Promotion
  *
  * @param {object} query The query search
  * @returns {Observable<Promotion[]>} The array promotions observable.
  */
  searchAdmin(query: any): Observable<Promotion[]> {
    return this.http.get("http://localhost:3000/adminPromotions").map((res: Response) => {
      let promotions = res.json();
      if (promotions) {
        // get by category
        if (query.promotionCategory && query.promotionCategory !== "") {
          promotions = promotions.filter(item => item.promotionCategory === query.promotionCategory)
        }
        // search promotion Name
        if (query.promotionName && query.promotionName !== "") {
          promotions = promotions.filter(item => item.promotionName.toLowerCase().indexOf(query.promotionName.toLowerCase()) !== -1);
        }

        // search by promotion name ,merchant name, category
        if (query.searchName && query.searchName !== "") {
          promotions = promotions.filter(item => {
            if (item.promotionName.toLowerCase().indexOf(query.searchName.toLowerCase()) !== -1
              || item.promotionMerchant.toLowerCase().indexOf(query.searchName.toLowerCase()) !== -1
              || item.merchantCategory.toLowerCase().indexOf(query.searchName.toLowerCase()) !== -1) {
              return true;
            }
            return false;
          });
        }
        // search promotion start Date
        if (query.promotionStartDate && query.promotionStartDate !== "") {
          const startDate = new Date(query.promotionStartDate);
          promotions = promotions.filter(item => {
            const dateItem = new Date(item.promotionStartDate);
            if (startDate <= dateItem) {
              return true;
            }
            return false;
          });
        }
        // search promotion end Date
        if (query.promotionEndDate && query.promotionEndDate !== "") {
          const endDate = new Date(query.promotionEndDate);
          promotions = promotions.filter(item => {
            const dateItem = new Date(item.promotionStartDate);
            if (endDate >= dateItem) {
              return true;
            }
            return false;
          });
        }
        // search promotion status
        if (query.promotionStatus && query.promotionStatus !== "" && query.promotionStatus !== "All") {
          promotions = promotions.filter(item => item.promotionStatus.toLowerCase() === query.promotionStatus.toLowerCase());
        }
        return promotions;
      }
    })
  }
}
