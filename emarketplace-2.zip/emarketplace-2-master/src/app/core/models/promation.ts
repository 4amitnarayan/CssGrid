export class Promotion {
  id?: string;
  promotionId?: string;
  promotionMode?: string;
  promotionStatus?: string;
  promotionStartDate?: string;
  promotionEndDate?: string;
  promotionName?: string;
  promotionCategory?: string;
  promotionMerchant?: string;
  promotionDescription?: string;
  promotionUrl?: string;
  promotionEmail?: string[];
  promotionTermsConditions?: string[];
  promotionCountry?: any[];
}
