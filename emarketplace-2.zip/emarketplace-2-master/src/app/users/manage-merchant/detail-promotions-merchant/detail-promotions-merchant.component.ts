import { Component, OnInit, ViewChild, ElementRef, ViewChildren, QueryList, Renderer2, HostListener } from "@angular/core";
import { DataService } from "../../../core/services/data.service";
import { FormControl } from "@angular/forms";
import { MatDialog } from "@angular/material";
import { UploadDocumentModalComponent } from "../../../shared/upload-document-modal/upload-document-modal.component";
import { SendForReviewModalComponent } from "../../../shared/send-for-review-modal/send-for-review-modal.component";
import { Route, Router, ActivatedRoute } from "@angular/router";
import { DomSanitizer } from "@angular/platform-browser";
import { DatepickerComponent } from "../../../shared/datepicker/datepicker.component";
import { Promotion } from "../../../core/models/promation";
import { PromotionsService } from "../../../core/services/promation";

@Component({
  selector: "app-detail-promotions-merchant",
  templateUrl: "./detail-promotions-merchant.component.html",
  styleUrls: ["./detail-promotions-merchant.component.scss"]
})
export class DetailPromotionsMerchantComponent implements OnInit {
  // Promotion Create
  public promotion: Promotion;
  // number tab
  public numberTab = 0;
  // tab 1
  public listEmailCompany: any[] = [];
  public txtEmail: string;
  // text MS error load json
  public errorMessage: string;

  // list country
  public countries: any[] = [];
  // item contries select stores
  public promotingCountrySelected: any;
  // list sctore of promoting country
  public stores: any[];
  // list alphabetical
  public alphabetical: any[];
  // liste credit card
  public creditCards: any[];
  // query search store
  public querySearchStore = "";
  public isOnline = false;

  public isCheckedAll = false;
  public showClearChecked = false;
  public showPopupAllStoreChecked = false;
  public showPopupCountStoreChecked = false;
  public showContentSubmit = false;

  // credit card
  public isCheckedAllCard = false;
  public showPopupCountCardChecked = false;
  public showPopupAllCardChecked = false;
  public showClearCardChecked = false;
  // variable check after send for Review
  public modeSendReview = false;
  // step
  public step = 1;
  public stepTitle = "normalMode";
  // list channels
  public channels: any[];
  public channelSelect: any;
  public txtSeoKeyTag: string;
  // list comment history
  public listCommentHistory = [];
  public txtComment = "";
  @ViewChild("channelError") channelErrorMessEl: ElementRef;
  @ViewChild("dStart") dStart: DatepickerComponent;
  @ViewChild("dEnd") dEnd: DatepickerComponent;
  @ViewChildren("eleHistory") elHistory: QueryList<any>;
  // title tab
  public titleTab = "Promotion details";
  constructor(
    private dataService: DataService,
    private dialog: MatDialog,
    private renderer: Renderer2,
    private route: ActivatedRoute,
    private router: Router,
    private promotionSvc: PromotionsService
  ) {
    const id = this.route.snapshot.paramMap.get("id");
    this.promotionSvc.getAdminPromationById(id).subscribe(promotion => {
      this.promotion = promotion[0];
      if (this.promotion.promotionMode === "Online") {
        this.isOnline = true;
      }
    });
  }

  ngOnInit() {
    this.onload();
  }

  // on load data
  onload(): void {
    this.dataService.getData("http://localhost:3000/countries").subscribe(
      data => {
        this.countries = data || [];
        for (let i = 0; i < this.countries.length; i++) {
          const country = this.countries[i];
          for (let j = 0; j < this.promotion.promotionCountry.length; j++) {
            const element = this.promotion.promotionCountry[j];
            if (country.countryName === element.countryName) {
              this.countries[i].selected = true;
            }
          }
        }
      },
      error => this.errorMessage = <any>error
    );

    // get array alphabetical json
    this.dataService.getData("http://localhost:3000/alphabetical").subscribe(
      data => {
        this.alphabetical = data || [];
      },
      error => this.errorMessage = <any>error
    );

    // get data channels
    this.dataService.getData("http://localhost:3000/channels").subscribe(
      data => {
        this.channels = data || [];
      },
      error => this.errorMessage = <any>error
    );

    // load credit Card
    this.dataService.getData("http://localhost:3000/creditCard").subscribe(
      data => {
        this.creditCards = data;
      },
      error => this.errorMessage = <any>error
    );
  }

  // set promotion Mode
  setOnlineOfferFunc(): void {
    if (!this.modeSendReview) {
      this.isOnline = !this.isOnline;
      if (this.isOnline) {
        this.promotion.promotionMode = "Online";
      } else {
        this.promotion.promotionMode = "Offine";
      }
    }
  }

  // select tab
  selectTabContent(event): void {
    this.numberTab = event.index;
  }

  // callback open start datepicker
  callbackDStartShow(): void {
    this.dEnd.hiddenDatepicker();
    this.hiddenAllHistoryDetail();
  }

  // callback open end datepicker
  callbackDEndShow(): void {
    this.dStart.hiddenDatepicker();
    this.hiddenAllHistoryDetail();
  }

  // get description store of element country selected
  getDetailStoreByCountry(country): string {
    if (country.stores.length > 0 && country.stores.length <= 5) {
      return country.stores.length + " Stores";
    } else if (country.stores.length > 5) {
      return "All Stores";
    } else {
      return "Select Stores"
    }
  }
  // add object promotings countries
  addPromotingsCountry(country): void {
    let check = false;
    for (let i = 0; i < this.promotion.promotionCountry.length; i++) {
      const el = this.promotion.promotionCountry[i];
      if (el.countryName.toLowerCase() === country.countryName.toLowerCase()) {
        check = true;
      }
    }
    if (!check) {
      this.promotion.promotionCountry.push(country);
      country.selected = true;
      country.stores = [];
    }
  }
  // select store for promoting country element
  addStoreForPromotingCountry(country): void {
    this.isCheckedAll = false;
    this.promotingCountrySelected = Object.assign({}, country);
    this.loadStoreByCountry();
    this.showPopupAllStoreChecked = false;
    this.showPopupCountStoreChecked = false;
  }
  // load store on promoting country
  loadStoreByCountry(): void {
    this.dataService.getData("http://localhost:3000/stores").subscribe(
      data => {
        this.stores = data || [];
        if (this.promotingCountrySelected.stores.length > 0) {
          for (let i = 0; i < this.stores.length; i++) {
            const store = this.stores[i];
            for (let j = 0; j < this.promotingCountrySelected.stores.length; j++) {
              const element = this.promotingCountrySelected.stores[j];
              if (store.storeId === element.storeId) {
                store.isChecked = element.isChecked;
              }
            }
          }
          this.initOnloadStore();
        }
      },
      error => this.errorMessage = <any>error
    );
  }

  // init on load store
  initOnloadStore(): void {
    this.showPopupCountStoreChecked = false;
    this.showClearChecked = false;
    this.showPopupAllStoreChecked = false;
  }
  // toggle checked store
  toggleCheckedStore(item): void {
    item.isChecked = !item.isChecked;
    this.checkAllStoreSelect();
  }
  // select all store
  selectAllStore(): void {
    this.isCheckedAll = !this.isCheckedAll;
    for (let i = 0; i < this.stores.length; i++) {
      this.stores[i].isChecked = this.isCheckedAll;
    }
    this.checkAllStoreSelect();
  }
  // check all store selected
  checkAllStoreSelect(): void {
    this.showPopupCountStoreChecked = false;
    this.showClearChecked = false;
    for (let i = 0; i < this.stores.length; i++) {
      if (this.stores[i].isChecked) {
        this.showClearChecked = true;
      } else {
        this.isCheckedAll = false;
        this.showPopupAllStoreChecked = false;
      }
    }
    // show popup when select store
    if (this.showClearChecked && !this.isCheckedAll) {
      this.showPopupCountStoreChecked = true;
    } else if (this.isCheckedAll) {
      this.showPopupAllStoreChecked = true;
    }
  }
  // count store selected
  countStoreSelected(): number {
    let temp = 0;
    for (let i = 0; i < this.stores.length; i++) {
      const element = this.stores[i];
      if (element.isChecked) {
        temp++;
      }
    }
    return temp;
  }
  // clear Store Selected
  clearStoreSeleted(): void {
    for (let i = 0; i < this.stores.length; i++) {
      this.stores[i].isChecked = false;
    }
    this.isCheckedAll = false;
    this.showClearChecked = false;
    this.showPopupAllStoreChecked = false;
  }
  // back content select valid
  backValidStoresFunc(): void {
    this.promotingCountrySelected = undefined;
  }

  // confirm select store
  confirmSelectStore(): void {
    this.promotingCountrySelected.stores = [];
    for (let i = 0; i < this.stores.length; i++) {
      const store = this.stores[i];
      if (store.isChecked) {
        this.promotingCountrySelected.stores.push(store);
      }
    }
    // update promoting country after select store
    for (let i = 0; i < this.promotion.promotionCountry.length; i++) {
      const country = this.promotion.promotionCountry[i];
      if (country.id === this.promotingCountrySelected.id) {
        this.promotion.promotionCountry[i] = Object.assign({}, this.promotingCountrySelected);
        this.promotingCountrySelected = undefined;
        return;
      }
    }
    this.showPopupAllStoreChecked = false;
    this.showPopupCountStoreChecked = false;
  }
  // submit
  btnSubmitFunc(): void {
    this.showContentSubmit = true;
  }
  // cancel submit
  cancelSubmitFunc(): void {
    this.showContentSubmit = false;
  }

  // add list email
  addListEmailFunc(): void {
    if (this.txtEmail !== "") {
      this.promotion.promotionEmail.push(this.txtEmail);
    }
    this.txtEmail = "";
  }

  // delete item email
  deleteItemEmail(index): void {
    this.promotion.promotionEmail.splice(index, 1);
  }

  // callback select start date from datepicker
  callBackStartDate(value): void {
    if (value) {
      this.promotion.promotionStartDate = value;
    }
  }

  // callback select start date from datepicker
  callBackEndDate(value): void {
    if (value) {
      this.promotion.promotionEndDate = value;
    }
  }

  // check submit data
  checkSubmitPromotion(): boolean {
    return true;
  }

  // open modal upload document
  openModalUpload(): void {
    const dialogRef = this.dialog.open(UploadDocumentModalComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result === "next") {
        this.step = 2;
        this.stepTitle = "selectChannelMode";
      }
    });
  }

  // open modal send for review
  openModalSendForReview(): void {
    const dialogRef = this.dialog.open(SendForReviewModalComponent, {
      width: "792px",
      height: "348px"
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === "submit") {
        this.modeSendReview = true;
      }
    });
  }

  // reject change after send for review
  rejectChangeFunc(): void {
    this.modeSendReview = false;
  }

  // approve change after send for review
  approveChangeFunc(): void {
    this.modeSendReview = false;
    this.stepTitle = "afterApproved";
  }

  // select Channel
  selectChannelFunc(channel): void {
    if (channel.selected) {
      this.channels.forEach(el => {
        el.selected = false;
      });
      this.channelSelect = undefined;
    } else {
      this.channels.forEach(el => {
        el.selected = false;
      });
      channel.selected = true;
      this.channelSelect = channel;
      this.channelSelect.tagSeo = [];
      this.channelSelect.credit = [];
      this.channelSelect.debit = [];
      this.channelSelect.readyCredit = [];
    }
    this.channelErrorMessEl.nativeElement.classList.add("hide");
  }

  // cancel mode select Channel
  cancelSelectChannel(): void {
    this.step = 1;
    this.stepTitle = "afterApproved";
    this.channelErrorMessEl.nativeElement.classList.add("hide");
  }

  // proceed channel
  proceedChannelFunc(): void {
    if (this.channelSelect) {
      this.stepTitle = "setupForChannel";
    } else {
      this.channelErrorMessEl.nativeElement.classList.remove("hide");
    }
  }

  // remove all history detail
  hiddenAllHistoryDetail(): void {
    if (this.elHistory) {
      this.elHistory.forEach(element => {
        this.renderer.removeClass(element.nativeElement, "active");
      });
    }
  }

  // edit history
  editHistoryDetails(event): void {
    event.stopPropagation();
    if (event.currentTarget.parentElement.classList.contains("active")) {
      this.hiddenAllHistoryDetail();
    } else {
      this.hiddenAllHistoryDetail();
      event.currentTarget.parentElement.classList.add("active");
    }
    this.dStart.hiddenDatepicker();
    this.dEnd.hiddenDatepicker();
  }

  // close history
  closeHistoryDetails(event): void {
    event.stopPropagation();
    event.currentTarget.parentElement.parentElement.parentElement.classList.remove("active");
  }

  // add Tag Seo Meta Key Word
  addTagSeoMetaKey(): void {
    if (this.txtSeoKeyTag) {
      this.channelSelect.tagSeo.push(this.txtSeoKeyTag);
      this.txtSeoKeyTag = "";
    }
  }

  // remove Tag
  removeTagSeo(index): void {
    this.channelSelect.tagSeo.splice(index, 1);
  }

  // cancel setup channel
  cancelSetupChannel(): void {
    this.stepTitle = "selectChannelMode";
  }

  // select tab content
  selectTabContentDetail(title): void {
    this.titleTab = title;
  }

  // back to previouse
  goBack(): void {
    this.router.navigate(["/users/manage-merchant/review-promotions-merchant-pending"]);
  }

  // add list comment edit history
  addListCommentHistory(): void {
    if (this.txtComment !== "") {
      this.listCommentHistory.push({
        comment: this.txtComment
      });
      this.txtComment = "";
    }
  }

  // delete list comment edit history
  deleteListCommentHistory(index): void {
    this.listCommentHistory.splice(index, 1)
  }

  // ======= credit card =========
  callbackSelectAllCreditCard(event): void {
    this.isCheckedAllCard = event.checked;
    for (let i = 0; i < this.creditCards.length; i++) {
      this.creditCards[i].isChecked = event.checked;
    }
    this.checkAllCreditCardSelect();
  }

  // check all store selected
  checkAllCreditCardSelect(): void {
    this.showPopupCountCardChecked = false;
    this.showClearCardChecked = false;
    for (let i = 0; i < this.creditCards.length; i++) {
      if (this.creditCards[i].isChecked) {
        this.showClearCardChecked = true;
      } else {
        this.isCheckedAllCard = false;
        this.showPopupAllCardChecked = false;
      }
    }
    // show popup when select store
    if (this.showClearCardChecked && !this.isCheckedAllCard) {
      this.showPopupCountCardChecked = true;
    } else if (this.isCheckedAllCard) {
      this.showPopupAllCardChecked = true;
    }
  }

  // toggle checked store
  callbackCheckedCreditCard(event, card): void {
    card.isChecked = event.checked;
    this.checkAllCreditCardSelect();
  }

  // clear Store Selected
  clearCardSeleted(): void {
    for (let i = 0; i < this.creditCards.length; i++) {
      this.creditCards[i].isChecked = false;
    }
    this.isCheckedAllCard = false;
    this.showClearCardChecked = false;
    this.showPopupAllCardChecked = false;
  }

  // confirm select store
  confirmSelectCard(): void {
    this.stepTitle = "setupForChannel";
    // this.stepTitle.stores = [];
    // for (let i = 0; i < this.stores.length; i++) {
    //   const store = this.stores[i];
    //   if (store.isChecked) {
    //     this.promotingCountrySelected.stores.push(store);
    //   }
    // }
    // // update promoting country after select store
    // for (let i = 0; i < this.promotion.promotionCountry.length; i++) {
    //   const country = this.promotion.promotionCountry[i];
    //   if (country.id === this.promotingCountrySelected.id) {
    //     this.promotion.promotionCountry[i] = Object.assign({}, this.promotingCountrySelected);
    //     this.promotingCountrySelected = undefined;
    //     return;
    //   }
    // }
    // this.showPopupAllStoreChecked = false;
    // this.showPopupCountStoreChecked = false;
  }

  // count store selected
  countCardSelected(): number {
    let temp = 0;
    for (let i = 0; i < this.creditCards.length; i++) {
      const element = this.creditCards[i];
      if (element.isChecked) {
        temp++;
      }
    }
    return temp;
  }

  // click select card
  selectCardsDetail(): void {
    this.stepTitle = "selectCreaditCard";
  }

  // cancel select card
  cancelSelectCardsDetail(): void {
    this.stepTitle = "setupForChannel";
  }

  // click body
  @HostListener("document:click", ["$event"])
  onClick(): void {
    this.hiddenAllHistoryDetail();
  }
}
