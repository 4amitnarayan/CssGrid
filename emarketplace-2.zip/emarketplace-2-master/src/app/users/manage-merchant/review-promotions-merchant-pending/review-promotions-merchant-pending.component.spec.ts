import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ReviewPromotionsMerchantPendingComponent } from "./review-promotions-merchant-pending.component";

import { FormsModule } from "@angular/forms";

import { MatFormFieldModule, MatDialogModule } from "@angular/material"

import { RangeDatepickerComponent } from "../../../shared/range-datepicker/range-datepicker.component";

import { OrderByPipe } from "../../../shared/order-by/order-by.pipe";

import { BsDatepickerModule } from "ngx-bootstrap";

import { PagerService } from "../../../core/services/pager.service";

import { PromotionsService } from "../../../core/services/promation";

import { DataService } from "../../../core/services/data.service";

import { HttpModule } from "@angular/http";

import { RouterModule } from "@angular/router";

import {APP_BASE_HREF} from "@angular/common";

import {MatInputModule} from "@angular/material";

import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

describe("ReviewPromotionsMerchantPendingComponent", () => {
  let component: ReviewPromotionsMerchantPendingComponent;
  let fixture: ComponentFixture<ReviewPromotionsMerchantPendingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewPromotionsMerchantPendingComponent, RangeDatepickerComponent, OrderByPipe ],
      imports: [ FormsModule, MatFormFieldModule, BsDatepickerModule.forRoot(), 
        HttpModule, MatInputModule, BrowserAnimationsModule, MatDialogModule,
        RouterModule.forRoot([{
          path: "",
          component: ReviewPromotionsMerchantPendingComponent
        }])
      ],
      providers: [ PagerService, PromotionsService, DataService,
        {
          provide: APP_BASE_HREF, useValue : "/"
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewPromotionsMerchantPendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
