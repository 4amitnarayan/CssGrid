import { Component, OnInit, HostListener, ViewChildren, QueryList, Renderer2, ViewChild, ElementRef } from "@angular/core";
import { PromotionsService } from "../../../core/services/promation";
import { PagerService } from "../../../core/services/pager.service";
import { Router } from "@angular/router";
import { RangeDatepickerComponent } from "../../../shared/range-datepicker/range-datepicker.component";
import { DatePipe } from "@angular/common";
import { Promotion } from "../../../core/models/promation";

@Component({
  selector: "app-review-promotions-merchant-past",
  templateUrl: "./review-promotions-merchant-past.component.html",
  styleUrls: ["./review-promotions-merchant-past.component.scss"],
  providers: [DatePipe]
})
export class ReviewPromotionsMerchantPastComponent implements OnInit {
  @ViewChild("contentPage") contentPageEl: ElementRef;
  public promotions: Promotion[] = [];
  public showEmptyPromotion = false;
  // array of all items to be paged
  private allItems: any[];

  // pager object
  public pager: any = {};
  public currentPage = 1;

  // promotions items
  public promotionsItems: any[];
  public querySearchPromotions = "";
  public showSortBy = false;
  public orderByType = false;
  public columnsTitle: string;
  @ViewChildren("titleCol") titleCols: QueryList<any>;
  @ViewChildren("itemListSort") itemListSorts: QueryList<any>;
  @ViewChild("rangerDatepicker") rangerDatepickerEl: RangeDatepickerComponent;

  // query search
  public queryPromotionsName: string;
  public queryPromotionsStartDate: string;
  public queryPromotionsEndDate: string;
  public queryTypeDate: string;
  constructor(
    private pagerSvc: PagerService,
    private promotionsSvc: PromotionsService,
    private renderer: Renderer2,
    private datePipe: DatePipe,
    private router: Router
  ) { }

  ngOnInit() {
    this.onLoadData();
  }

  onLoadData(): void {
    this.promotionsSvc.getAdminPromationByCategory("past").subscribe(
      data => {
        this.promotions = data;
        this.setPage(1);
      },
      error => { }
    );
  }

  // go to detail Promotion
  goDetailPromotion(promotion): void {
    this.router.navigate(["/users/manage-merchant/detail-promotions-merchant", promotion.id]);
  }

  // set page
  setPage(page) {
    this.currentPage = page;
    this.paginationFunc();
  }
  // get title page
  getTitltePage(pageNumber): string {
    if (pageNumber < 10) {
      return "0" + pageNumber;
    }
    return pageNumber;
  }

  // pagination function
  paginationFunc(): void {
    this.pager = {};
    if (this.currentPage < 1 || this.currentPage > this.pager.totalPages) {
      return;
    }
    // get pager object from service
    this.pager = this.pagerSvc.getPager(this.promotions.length, this.currentPage);

    // get current page of items
    this.promotionsItems = this.promotions.slice(this.pager.startIndex, this.pager.endIndex + 1);
    if (this.contentPageEl) {
      const that = this;
      this.contentPageEl.nativeElement.style.height = "auto";
      setTimeout(function () {
        const heightElement = that.contentPageEl.nativeElement.offsetHeight;
        const heightWindow = window.innerHeight;
        if (heightElement + 95 < heightWindow) {
          that.contentPageEl.nativeElement.style.height = heightWindow - 95 + "px";
        }
      }, 50);
    }
  }
  // remove all class
  removeClassAllItem(): void {
    this.titleCols.forEach(element => {
      this.renderer.removeClass(element.nativeElement, "active");
    });
    if (this.rangerDatepickerEl) {
      this.rangerDatepickerEl.hiddenRangerDatepicker();
    }
  }


  // show tooltip filter table on column
  showTooltipsColTable(event, value): void {
    event.stopPropagation();
    if (event.currentTarget.parentElement.classList.contains("active")) {
      this.removeClassAllItem();
    } else {
      this.removeClassAllItem();
      event.currentTarget.parentElement.classList.add("active");
      if (value === "date") {
        this.rangerDatepickerEl.showRangerDatepicker();
      }
    }
    this.showSortBy = false;
  }

  // show sort by
  showSortByTooltip(): void {
    this.showSortBy = !this.showSortBy;
    this.removeClassAllItem();
  }

  // remove all class active title column
  removeClassAllListSort(): void {
    this.itemListSorts.forEach(element => {
      this.renderer.removeClass(element.nativeElement, "active");
    });
  }
  // sort order by
  sortOrderByFunc(columns, title, event): void {
    this.columnsTitle = columns;
    if (title === "Promotion Name A - Z" || title === "Status A - Z" || title === "Lasted To Oldest") {
      this.orderByType = false;
    } else {
      this.orderByType = true;
    }

    this.removeClassAllListSort();
    this.renderer.addClass(event.currentTarget.parentElement, "active");
  }

  // select type query Date
  selectFilterByDate(typeDate) {
    const today: any = new Date;
    if (typeDate === "Ranger") {
      if (!this.queryPromotionsStartDate) {
        this.queryTypeDate = "From "
          + this.datePipe.transform(this.queryPromotionsStartDate, "dd MMM")
          + "-"
          + this.datePipe.transform(this.queryPromotionsEndDate, "dd MMM")
        this.removeClassAllItem();
      }
    } else if (typeDate === "All") {
      this.queryTypeDate = typeDate;
      this.onLoadData();
      this.removeClassAllItem();
      this.queryPromotionsStartDate = undefined;
      this.queryPromotionsEndDate = undefined;
      this.rangerDatepickerEl.resetValue();
    } else {
      this.queryPromotionsStartDate = today;
      this.queryTypeDate = typeDate;
      this.removeClassAllItem();
      this.searchFunc();
      this.rangerDatepickerEl.setToDateForCalendar();
    }
  }

  callBackDatePicker(value): void {
    const today: any = new Date;
    if (!value.startDate && !value.endDate) {
      this.queryTypeDate = "Today";
      this.queryPromotionsStartDate = today;
      this.queryPromotionsEndDate = today;
    } else {
      this.queryPromotionsStartDate = value.startDate;
      this.queryPromotionsEndDate = value.endDate;
      this.queryTypeDate = "From "
        + this.datePipe.transform(this.queryPromotionsStartDate, "d MMM")
        + "-"
        + this.datePipe.transform(this.queryPromotionsEndDate, "d MMM");
    }
    this.searchFunc();
  }
  // search data
  searchFunc(): void {
    this.promotionsSvc.search({
      "promotionCategory": "past",
      "promotionName": this.queryPromotionsName,
      "promotionStartDate": this.queryPromotionsStartDate,
      "promotionEndDate": this.queryPromotionsEndDate
    }).subscribe(
      data => {
        this.promotions = data;
        this.setPage(1);
      },
      error => { }
    );
  }

  // click body
  @HostListener("document:click", ["$event"])
  onClick(): void {
    this.showSortBy = false;
    this.removeClassAllItem();
  }
}
