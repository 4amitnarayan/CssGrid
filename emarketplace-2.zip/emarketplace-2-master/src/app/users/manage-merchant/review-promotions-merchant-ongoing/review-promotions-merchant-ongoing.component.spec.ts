import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ReviewPromotionsMerchantOngoingComponent } from "./review-promotions-merchant-ongoing.component";

import { FormsModule } from "@angular/forms";

import { MatFormFieldModule } from "@angular/material"

import { RangeDatepickerComponent } from "../../../shared/range-datepicker/range-datepicker.component";

import { OrderByPipe } from "../../../shared/order-by/order-by.pipe";

import { BsDatepickerModule } from "ngx-bootstrap";

import { PagerService } from "../../../core/services/pager.service";

import { PromotionsService } from "../../../core/services/promation";

import { DataService } from "../../../core/services/data.service";

import { HttpModule } from "@angular/http";

import { RouterModule } from "@angular/router";

import {APP_BASE_HREF} from "@angular/common";

import {MatInputModule} from "@angular/material";

import { BrowserAnimationsModule } from "@angular/platform-browser/animations";


describe("ReviewPromotionsMerchantOngoingComponent", () => {
  let component: ReviewPromotionsMerchantOngoingComponent;
  let fixture: ComponentFixture<ReviewPromotionsMerchantOngoingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewPromotionsMerchantOngoingComponent, RangeDatepickerComponent, OrderByPipe ],
      imports: [ FormsModule, MatFormFieldModule, BsDatepickerModule.forRoot(), HttpModule, MatInputModule, BrowserAnimationsModule,
        RouterModule.forRoot([{
          path: "",
          component: ReviewPromotionsMerchantOngoingComponent
        }])
      ],
      providers: [ PagerService, PromotionsService, DataService,
        {
          provide: APP_BASE_HREF, useValue : "/"
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewPromotionsMerchantOngoingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
