import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";


import { ManageMerchantComponent } from "./manage-merchant.component";

import { RouterModule } from "@angular/router";

import {APP_BASE_HREF} from "@angular/common";

import { PromotionsService } from "../../core/services/promation";

import { HttpModule } from "@angular/http";

describe("ManageMerchantComponent", () => {
  let component: ManageMerchantComponent;
  let fixture: ComponentFixture<ManageMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ RouterModule.forRoot([{
        path: "",
        component: ManageMerchantComponent
      }]),
      HttpModule
    ],
      declarations: [ ManageMerchantComponent ],
      schemas: [ NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ],
      providers: [
        {
          provide: APP_BASE_HREF, useValue : "/"
        },
        PromotionsService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
