import { Component, OnInit } from "@angular/core";

import { DataService } from "../../../core/services/data.service";

/**
 * The user"s account.
 * @class MyAccountComponent
 */
@Component({
  selector: "app-my-account",
  templateUrl: "./my-account.component.html",
  styleUrls: ["./my-account.component.scss"]
})
export class MyAccountComponent implements OnInit {

  /**
   * route load json
   * @type {Array, String}
  */
 listRoute: Array<any>
 errorMessage: String


  /**
   * @constructor
   */
  constructor(
    private dataService: DataService
  ) { }

  /**
   * Lifecycle hook that is called after data-bound properties of a directive are initialized.
   * @method ngOnInit
   */
  ngOnInit() {

    this.onload();
  }

  onload = (): void => {
    this.dataService.getData("assets/data/MyLinks.json").subscribe(
      data => {
        this.listRoute = data.tabMyAccount;
      },
      error => this.errorMessage = <any>error
    );
  }

}
