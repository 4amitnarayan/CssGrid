import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { DataService } from "../../../../core/services/data.service";
import { HttpModule } from "@angular/http";

import { MatDialogRef, MatDialog } from "@angular/material";
import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";

import { MyProfileComponent } from "./my-profile.component";

describe("MyProfileComponent", () => {
  let component: MyProfileComponent;
  let fixture: ComponentFixture<MyProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule
      ],
      providers: [
        {
          provide: MatDialogRef,
          useValue: {close: (dialogResult: any) => {}}
        },
        {
          provide: MatDialog,
          useValue: {close: (dialogResult: any) => {}}
        },
        FormBuilder,
        DataService
      ],
      declarations: [ MyProfileComponent ],
      schemas: [ NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
