import { Component, OnInit } from "@angular/core";
import { DataService } from "../../../../core/services/data.service";

@Component({
  selector: "app-stores",
  templateUrl: "./stores.component.html",
  styleUrls: ["./stores.component.scss"],
  providers: [DataService]
})
export class StoresComponent implements OnInit {

  // list stores
  stores: any[] = [];

  // text MS error load json
  errorMessage: string;

  constructor(
    private dataService: DataService
  ) { }

  ngOnInit() {
    this.onload();
  }

  onload(): void {
    this.dataService.getData("http://localhost:3000/stores").subscribe(
      data => {
        this.stores = data;
      },
      error => this.errorMessage = <any>error
    );
  }

  delete(store: string, list: string[]): void {
    const index = list.indexOf(store, 0);
    if (index > -1) {
      this.stores = list.filter(li => list.indexOf(li, 0) !== index)
    }
  }

}
