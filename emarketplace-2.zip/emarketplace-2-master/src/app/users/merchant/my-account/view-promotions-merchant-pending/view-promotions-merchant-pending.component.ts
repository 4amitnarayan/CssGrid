import {
  Component, OnInit, ViewChild, AfterViewChecked, ViewChildren, QueryList,
  Renderer2, HostListener, ElementRef
} from "@angular/core";
import { DatePipe } from "@angular/common";
import { MatDialog, MAT_PAGINATOR_INTL_PROVIDER_FACTORY } from "@angular/material";
import { PromotionsService } from "../../../../core/services/promation";
import { PagerService } from "../../../../core/services/pager.service";
import { DeletePendingPromotionModalComponent } from "../../../../shared/delete-pending-promotion-modal/delete-pending-promotion-modal.component";
import { RangeDatepickerComponent } from "../../../../shared/range-datepicker/range-datepicker.component";
@Component({
  selector: "app-view-promotions-merchant-pending",
  templateUrl: "./view-promotions-merchant-pending.component.html",
  styleUrls: ["./view-promotions-merchant-pending.component.scss"],
  providers: [DatePipe]
})
export class ViewPromotionsMerchantPendingComponent implements OnInit {
  @ViewChild("contentPage") contentPageEl: ElementRef;
  public promotions: any[] = [];
  public showEmptyPromotion = false;
  // array of all items to be paged
  private allItems: any[];

  // pager object
  public pager: any = {};
  public currentPage = 1;

  // promotions items
  public promotionsItems: any[];
  public showSortBy = false;
  public orderByType = false;
  public columnsTitle: string;
  @ViewChildren("titleCol") titleCols: QueryList<any>;
  @ViewChildren("itemListSort") itemListSorts: QueryList<any>;
  @ViewChild("rangerDatepicker") rangerDatepickerEl: RangeDatepickerComponent;

  // query search
  public queryPromotionsName: string;
  public queryPromotionsStartDate: string;
  public queryPromotionsEndDate: string;
  public queryTypeDate: string;
  public queryTypeStatus: string;

  constructor(
    private promotionsSvc: PromotionsService,
    private pagerSvc: PagerService,
    private renderer: Renderer2,
    private datePipe: DatePipe,
    private dialog: MatDialog
  ) {
  }

  ngOnInit() {
    this.onLoadData();
  }

  // on load
  onLoadData(): void {
    this.promotionsSvc.getPromationByCategory("pending").subscribe(
      data => {
        this.promotions = data;
        this.setPage(1);
      },
      error => { }
    );
  }

  // remove all class active title column
  removeClassAllListSort(): void {
    this.itemListSorts.forEach(element => {
      this.renderer.removeClass(element.nativeElement, "active");
    });
  }
  // show tooltip filter table on column
  showTooltipsColTable(event, value): void {
    event.stopPropagation();
    if (event.currentTarget.parentElement.classList.contains("active")) {
      this.removeClassAllItem();
    } else {
      this.removeClassAllItem();
      event.currentTarget.parentElement.classList.add("active");
      if (value === "date") {
        this.rangerDatepickerEl.showRangerDatepicker();
      }
    }
    this.showSortBy = false;
  }
  // set page
  setPage(page) {
    this.currentPage = page;
    this.paginationFunc();
  }

  // get title page
  getTitltePage(pageNumber): string {
    if (pageNumber < 10) {
      return "0" + pageNumber;
    }
    return pageNumber;
  }

  // pagination function
  paginationFunc(): void {
    this.pager = {};
    if (this.currentPage < 1 || this.currentPage > this.pager.totalPages) {
      return;
    }
    // get pager object from service
    this.pager = this.pagerSvc.getPager(this.promotions.length, this.currentPage);
    // get current page of items
    this.promotionsItems = this.promotions.slice(this.pager.startIndex, this.pager.endIndex + 1);
    if (this.contentPageEl) {
      const that = this;
      this.contentPageEl.nativeElement.style.height = "auto";
      setTimeout(function () {
        const heightElement = that.contentPageEl.nativeElement.offsetHeight;
        const heightWindow = window.innerHeight;
        if (heightElement + 95 < heightWindow) {
          that.contentPageEl.nativeElement.style.height = heightWindow - 95 + "px";
        }
      }, 50);
    }
  }

  // remove all class
  removeClassAllItem(): void {
    this.titleCols.forEach(element => {
      this.renderer.removeClass(element.nativeElement, "active");
    });
    if (this.rangerDatepickerEl) {
      this.rangerDatepickerEl.hiddenRangerDatepicker();
    }
  }

  // show sort by
  showSortByTooltip(): void {
    this.showSortBy = !this.showSortBy;
    this.removeClassAllItem();
  }

  // sort order by
  sortOrderByFunc(columns, title, event): void {
    this.columnsTitle = columns;
    if (title === "Promotion Name A - Z" || title === "Status A - Z" || title === "Lasted To Oldest") {
      this.orderByType = false;
    } else {
      this.orderByType = true;
    }
    this.removeClassAllListSort();
    this.renderer.addClass(event.currentTarget.parentElement, "active");
  }

  // delete promotions
  deletePromotionFunc(index): void {
    const dialogRef = this.dialog.open(DeletePendingPromotionModalComponent, {
      width: "283px",
      height: "150px",
      data: { index: index }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (typeof result !== "undefined") {
        this.promotions.splice(result, 1);
        this.paginationFunc();
      }
    });
  }
  // Filter Promotion
  // select type query Date
  selectFilterByDate(typeDate) {
    const today: any = new Date;
    if (typeDate === "Ranger") {
      if (!this.queryPromotionsStartDate) {
        this.queryTypeDate = "From "
          + this.datePipe.transform(this.queryPromotionsStartDate, "dd MMM")
          + "-"
          + this.datePipe.transform(this.queryPromotionsEndDate, "dd MMM")
        this.removeClassAllItem();
      }
    } else if (typeDate === "All") {
      this.queryTypeDate = typeDate;
      this.onLoadData();
      this.removeClassAllItem();
      this.queryPromotionsStartDate = undefined;
      this.queryPromotionsEndDate = undefined;
      this.rangerDatepickerEl.resetValue();
    } else {
      this.queryPromotionsStartDate = today;
      this.queryTypeDate = typeDate;
      this.removeClassAllItem();
      this.searchFunc();
      this.rangerDatepickerEl.setToDateForCalendar();
    }
  }

  callBackDatePicker(value): void {
    const today: any = new Date;
    if (!value.startDate && !value.endDate) {
      this.queryTypeDate = "Today";
      this.queryPromotionsStartDate = today;
      this.queryPromotionsEndDate = today;
    } else {
      this.queryPromotionsStartDate = value.startDate;
      this.queryPromotionsEndDate = value.endDate;
      this.queryTypeDate = "From "
        + this.datePipe.transform(this.queryPromotionsStartDate, "d MMM")
        + "-"
        + this.datePipe.transform(this.queryPromotionsEndDate, "d MMM");
    }
    this.searchFunc();
  }
  // select query status
  selectFilterByStatus(status) {
    this.queryTypeStatus = status;
    this.removeClassAllItem();
    this.searchFunc();
  }
  // search data
  searchFunc(): void {
    this.promotionsSvc.search({
      "promotionCategory": "pending",
      "promotionName": this.queryPromotionsName,
      "promotionStartDate": this.queryPromotionsStartDate,
      "promotionEndDate": this.queryPromotionsEndDate,
      "promotionStatus": this.queryTypeStatus
    }).subscribe(
      data => {
        this.promotions = data;
        this.setPage(1);
      },
      error => { }
    );
  }
  // click body
  @HostListener("document:click", ["$event"])
  onClick(): void {
    this.removeClassAllItem();
    this.showSortBy = false;
  }

}
