import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ViewPromotionsMerchantPendingComponent } from "./view-promotions-merchant-pending.component";

import { FormsModule } from "@angular/forms";

import { MatFormFieldModule, MatDialogModule, MatInputModule } from "@angular/material";

import { RangeDatepickerComponent} from "../../../../shared/range-datepicker/range-datepicker.component";

import { OrderByPipe } from "../../../../shared/order-by/order-by.pipe";

import { BsDatepickerModule, BsDatepickerConfig, ModalModule, BsDaterangepickerConfig, BsLocaleService } from "ngx-bootstrap";

import { PagerService } from "../../../../core/services/pager.service";

import { PromotionsService } from "../../../../core/services/promation";

import { DataService } from "../../../../core/services/data.service";

import { HttpModule } from "@angular/http";

import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

describe("ViewPromotionsMerchantPendingComponent", () => {
  let component: ViewPromotionsMerchantPendingComponent;
  let fixture: ComponentFixture<ViewPromotionsMerchantPendingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewPromotionsMerchantPendingComponent, RangeDatepickerComponent, OrderByPipe ],
      imports: [ FormsModule, MatFormFieldModule, BsDatepickerModule.forRoot(), HttpModule, MatDialogModule, ModalModule.forRoot(), MatInputModule,
        BrowserAnimationsModule ],
      providers: [ PagerService, PromotionsService, DataService, BsDaterangepickerConfig, BsLocaleService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPromotionsMerchantPendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
