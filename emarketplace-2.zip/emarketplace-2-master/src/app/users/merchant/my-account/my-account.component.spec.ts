/* tslint:disable:no-unused-variable */
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { async, ComponentFixture, TestBed } from "@angular/core/testing";

// services
import { DataService } from "../../../core/services/data.service";
import { HttpModule } from "@angular/http";

// this component to test
import { MyAccountComponent } from "./my-account.component";

describe("MyAccountComponent", () => {

  let component: MyAccountComponent;
  let fixture: ComponentFixture<MyAccountComponent>;

  beforeEach(async(() => {
    // refine the test module by declaring the test component
    TestBed.configureTestingModule({
      imports: [
        HttpModule
      ],
      declarations: [
        MyAccountComponent
      ],
      providers: [
        DataService
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
    .compileComponents();

    // create component and test fixture
    fixture = TestBed.createComponent(MyAccountComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
  }));

  it("should create an instance", () => {
   expect(component).toBeTruthy();
  });
});
