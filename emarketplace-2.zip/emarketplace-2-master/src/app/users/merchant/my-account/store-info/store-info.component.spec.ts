import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { DataService } from "../../../../core/services/data.service";
import { HttpModule } from "@angular/http";

import { RouterTestingModule } from "@angular/router/testing";
import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";

import { StoreInfoComponent } from "./store-info.component";

describe("StoreInfoComponent", () => {
  let component: StoreInfoComponent;
  let fixture: ComponentFixture<StoreInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
        RouterTestingModule
      ],
      providers: [
        DataService,
        FormBuilder
      ],
      declarations: [ StoreInfoComponent ],
      schemas: [ NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
