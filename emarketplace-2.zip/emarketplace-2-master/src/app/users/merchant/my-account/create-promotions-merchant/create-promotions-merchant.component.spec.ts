import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CreatePromotionsMerchantComponent } from "./create-promotions-merchant.component";

import { MatTabsModule, MatFormFieldModule, MatSlideToggleModule, MatCheckboxModule, MatDialogModule, MatInputModule } from "@angular/material";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { DatepickerComponent} from "../../../../shared/datepicker/datepicker.component";

import { FilterPipe } from "../../../../shared/filter/index";

import { FilterByAlphaPipe } from "../../../../shared/filter-by-alpha/filter-by-alpha.pipe";

import { FilterByAttrPipe } from "../../../../shared/filter-by-attr/filter-by-attr.pipe";

import { BsDatepickerModule, BsDatepickerConfig, ModalModule, BsLocaleService } from "ngx-bootstrap";

import { HttpModule } from "@angular/http";

import { PromotionsService } from "../../../../core/services/promation";

import { RouterModule } from "@angular/router";

import {APP_BASE_HREF} from "@angular/common";

import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

describe("CreatePromotionsMerchantComponent", () => {
  let component: CreatePromotionsMerchantComponent;
  let fixture: ComponentFixture<CreatePromotionsMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePromotionsMerchantComponent, DatepickerComponent, FilterPipe, FilterByAlphaPipe, FilterByAttrPipe ],
      imports: [ MatTabsModule, FormsModule, MatFormFieldModule, MatSlideToggleModule, ReactiveFormsModule,
        MatCheckboxModule, BsDatepickerModule, HttpModule, MatDialogModule, ModalModule.forRoot(), MatInputModule, BrowserAnimationsModule,
        RouterModule.forRoot([{
          path: "",
          component: CreatePromotionsMerchantComponent
        }]) ],
      providers: [ PromotionsService, BsLocaleService,
        {
          provide: APP_BASE_HREF, useValue : "/"
        },
        BsDatepickerConfig
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePromotionsMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
