import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, NO_ERRORS_SCHEMA } from "@angular/core";

import { StoreModule } from "@ngrx/store";

// reducers
import { reducers } from "../../reducers";


import { MerchantComponent } from "./merchant.component";

import { RouterModule } from "@angular/router";

import {APP_BASE_HREF} from "@angular/common";

import { PromotionsService } from "../../core/services/promation";

import { DataService } from "../../core/services/data.service";

import { HttpModule } from "@angular/http";

describe("MerchantComponent", () => {
  let component: MerchantComponent;
  let fixture: ComponentFixture<MerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(reducers),
        RouterModule.forRoot([{
          path: "",
          component: MerchantComponent
        }]),
        HttpModule
      ],
      declarations: [ MerchantComponent ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [
        {
          provide: APP_BASE_HREF, useValue : "/"
        },
        PromotionsService, DataService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
