import { Component, OnInit } from "@angular/core";

import { Cookie } from "ng2-cookies/ng2-cookies";

import { DataService } from "../../core/services/data.service";

// @ngrx
import { Store } from "@ngrx/store";

// rxjs
import { Observable } from "rxjs/Observable";



// reducers
import {
  getAuthenticatedUser,
  State
} from "../../reducers";

// models
import { User } from "../../core/models/user";
import { FormControl } from "@angular/forms";
import { Router } from "@angular/router";
import { PromotionsService } from "../../core/services/promation";

@Component({
  selector: "app-merchant",
  templateUrl: "./merchant.component.html",
  styleUrls: ["./merchant.component.scss"]
})
export class MerchantComponent implements OnInit {
  mode = new FormControl("side");
  public countPendingPromotion = 0;
  // the authenticated user
  public user: Observable<User>;
  public urlRouter: string;
  /**
   * route load json
   * @type {Array, String}
  */
  listRoute: Array<any>
  errorMessage: String

  /**
   * @constructor
   */
  constructor(
    private store: Store<State>,
    public router: Router,
    private promotionsService: PromotionsService) {
    router.events.subscribe((event: any) => {
      this.urlRouter = event.url
      console.log(this.urlRouter);
      this.onload();
    });
  }
  /**
   * Lifecycle hook that is called after data-bound properties of a directive are initialized.
   * @method ngOnInit
   */
  ngOnInit() {
    // get authenticated user
    this.user = this.store.select(getAuthenticatedUser);
    this.onload();
  }

  onload = (): void => {
    this.promotionsService.getNumberPromationByCategory("pending").subscribe(result => {
      this.countPendingPromotion = result;
    });
  }

}
