import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";

// @angular/flex-layout
import { FlexLayoutModule } from "@angular/flex-layout";

// components Authenticated
import { SignInComponent } from "./sign-in/sign-in.component";
import { SignUpComponent } from "./sign-up/sign-up.component";
import { ForgotUserComponent } from "./forgot-user/forgot-user.component";
import { ForgotPasswordComponent } from "./forgot-password/forgot-password.component";
import { ResetComponent } from "./reset/reset.component";

// components user view
import { MerchantComponent } from "./merchant/merchant.component";

// my account
import { MyAccountComponent } from "./merchant/my-account/my-account.component";
import { MyProfileComponent } from "./merchant/my-account/my-profile/my-profile.component";
import { MerchantDetailComponent } from "./merchant/my-account/merchant-detail/merchant-detail.component";
import { StoresComponent } from "./merchant/my-account/stores/stores.component";
import { StoreInfoComponent } from "./merchant/my-account/store-info/store-info.component";

// promotions tab ongoing

// components admin view
import { ManageMerchantComponent } from "./manage-merchant/manage-merchant.component";
import { DetailMerchantComponent } from "./manage-merchant/detail-merchant/detail-merchant.component";
import { InviteMerchantComponent } from "./invite-merchant/invite-merchant.component";
import { DetailUserComponent } from "./manage-merchant/detail-user/detail-user.component";
import { ListUserComponent } from "./manage-merchant/list-user/list-user.component";
import { ThisPageComponent } from "./manage-merchant/this-page/this-page.component";

// routing
import { UsersRoutingModule } from "./users-routing.module";

import { FilterPipe } from "../shared/filter/";
// import datepicker
import { BsDatepickerModule } from "ngx-bootstrap";
// import ng2 file upload
import { FileUploadModule } from "ng2-file-upload";
// emarket module
import { EmarketMaterialModule } from "emarket-material";
import { FilterByAlphaPipe } from "../shared/filter-by-alpha/filter-by-alpha.pipe";
import { FilterByAttrPipe } from "../shared/filter-by-attr/filter-by-attr.pipe";
import { OrderByPipe } from "../shared/order-by/order-by.pipe";
import { SetHeightDirective } from "../shared/set-height/set-height.directive";
import { SetHeightModalDirective } from "../shared/set-height-modal/set-height-modal.directive";
import {
  ViewPromotionsMerchantOngoingComponent
} from "./merchant/my-account/view-promotions-merchant-ongoing/view-promotions-merchant-ongoing.component";
import {
  ViewPromotionsMerchantPendingComponent
} from "./merchant/my-account/view-promotions-merchant-pending/view-promotions-merchant-pending.component";
import {
  ViewPromotionsMerchantPastComponent
} from "./merchant/my-account/view-promotions-merchant-past/view-promotions-merchant-past.component";
import {
  CreatePromotionsMerchantComponent
} from "./merchant/my-account/create-promotions-merchant/create-promotions-merchant.component";
import {
  ReviewPromotionsMerchantOngoingComponent
} from "./manage-merchant/review-promotions-merchant-ongoing/review-promotions-merchant-ongoing.component";
import {
  ReviewPromotionsMerchantPendingComponent
} from "./manage-merchant/review-promotions-merchant-pending/review-promotions-merchant-pending.component";
import {
  ReviewPromotionsMerchantPastComponent
} from "./manage-merchant/review-promotions-merchant-past/review-promotions-merchant-past.component";
import { DetailPromotionsMerchantComponent } from "./manage-merchant/detail-promotions-merchant/detail-promotions-merchant.component";
import { RangeDatepickerComponent } from "../shared/range-datepicker/range-datepicker.component";
import { DatepickerComponent } from "../shared/datepicker/datepicker.component";
import { UploadDocumentModalComponent } from "../shared/upload-document-modal/upload-document-modal.component";
import { DeletePendingPromotionModalComponent } from "../shared/delete-pending-promotion-modal/delete-pending-promotion-modal.component";
import { DeleteUploadDocumentModalComponent } from "../shared/delete-upload-document-modal/delete-upload-document-modal.component";
import { CancelUploadDocumentModalComponent } from "../shared/cancel-upload-document-modal/cancel-upload-document-modal.component";



// components constant
const components = [
  MerchantComponent,
  MyAccountComponent,
  MyProfileComponent,
  MerchantDetailComponent,
  StoresComponent,
  StoreInfoComponent,
  SignInComponent,
  SignUpComponent,
  ForgotUserComponent,
  ForgotPasswordComponent,
  ResetComponent,
  ManageMerchantComponent,
  DetailMerchantComponent,
  InviteMerchantComponent,
  DetailUserComponent,
  ListUserComponent,
  ThisPageComponent,
  FilterPipe,
  FilterByAlphaPipe,
  FilterByAttrPipe,
  OrderByPipe,
  SetHeightDirective,
  SetHeightModalDirective,
  ViewPromotionsMerchantOngoingComponent,
  ViewPromotionsMerchantPendingComponent,
  ViewPromotionsMerchantPastComponent,
  CreatePromotionsMerchantComponent,
  ReviewPromotionsMerchantOngoingComponent,
  ReviewPromotionsMerchantPendingComponent,
  ReviewPromotionsMerchantPastComponent,
  DetailPromotionsMerchantComponent,
  RangeDatepickerComponent,
  DatepickerComponent,
  UploadDocumentModalComponent,
  DeletePendingPromotionModalComponent,
  CancelUploadDocumentModalComponent,
  DeleteUploadDocumentModalComponent
];

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    UsersRoutingModule,
    BsDatepickerModule.forRoot(),
    FileUploadModule,
    EmarketMaterialModule // lib material component
  ],
  declarations: components,
  exports: components,
  entryComponents: [
    UploadDocumentModalComponent,
    DeletePendingPromotionModalComponent,
    CancelUploadDocumentModalComponent,
    DeleteUploadDocumentModalComponent
  ]
})
export class UsersModule { }
