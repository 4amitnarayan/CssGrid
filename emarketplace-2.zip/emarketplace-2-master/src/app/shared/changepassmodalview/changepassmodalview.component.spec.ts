import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { MatDialogRef } from "@angular/material";
import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";

import { ChangePassModalViewComponent } from "./changepassmodalview.component";

describe("ChangePassModalViewComponent", () => {
  let component: ChangePassModalViewComponent;
  let fixture: ComponentFixture<ChangePassModalViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangePassModalViewComponent ],
      providers: [
          {
          provide: MatDialogRef,
          useValue: {
            close: (dialogResult: any) => { }
          }
        },
        FormBuilder
      ],
      schemas: [ NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangePassModalViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
