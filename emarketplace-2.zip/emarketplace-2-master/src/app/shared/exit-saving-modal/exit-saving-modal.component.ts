import { Component, OnInit } from "@angular/core";
import { MatDialogRef } from "@angular/material";
import { Router } from "@angular/router";
@Component({
  selector: "app-exit-saving-modal",
  templateUrl: "./exit-saving-modal.component.html",
  styleUrls: ["./exit-saving-modal.component.scss"]
})
export class ExitSavingModalComponent {

  constructor(
    private router: Router,
    private dialogRef: MatDialogRef<ExitSavingModalComponent>
  ) { }

  // close dialog
  closeDialog(): void {
    this.dialogRef.close();
  }

  // confirm dialog
  confirmDialog(): void {
    this.dialogRef.close();
    this.router.navigate(["/users/merchant/my-account/view-promotions-merchant-pending"]);
  }

}
