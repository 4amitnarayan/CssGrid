import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CallbackSubmitAddPromotionModalComponent } from "./callback-submit-add-promotion-modal.component";

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { MatDialogRef } from "@angular/material";

import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";

describe("CallbackSubmitAddPromotionModalComponent", () => {
  let component: CallbackSubmitAddPromotionModalComponent;
  let fixture: ComponentFixture<CallbackSubmitAddPromotionModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CallbackSubmitAddPromotionModalComponent ],
      providers: [
        {
          provide: MatDialogRef,
          useValue: {
            close: (dialogResult: any) => { }
          }
        },
        FormBuilder
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallbackSubmitAddPromotionModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
