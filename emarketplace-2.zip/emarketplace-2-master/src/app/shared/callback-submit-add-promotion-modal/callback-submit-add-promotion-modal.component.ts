import { Component } from "@angular/core";
import { MatDialogRef } from "@angular/material";

@Component({
  selector: "app-callback-submit-add-promotion-modal",
  templateUrl: "./callback-submit-add-promotion-modal.component.html",
  styleUrls: ["./callback-submit-add-promotion-modal.component.scss"]
})
export class CallbackSubmitAddPromotionModalComponent {
  constructor(public dialogRef: MatDialogRef<CallbackSubmitAddPromotionModalComponent>) {
    setTimeout(() => {
      this.dialogRef.close();
    }, 3500);
  }
}
