import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { UploadDocumentModalComponent } from "./upload-document-modal.component";

import { FileUploadModule } from "ng2-file-upload";

import { MatDialog, MatDialogRef } from "@angular/material";

describe("UploadDocumentModalComponent", () => {
  let component: UploadDocumentModalComponent;
  let fixture: ComponentFixture<UploadDocumentModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadDocumentModalComponent ],
      imports: [ FileUploadModule ],
      providers: [
        {
          provide: MatDialog,
          useValue: {
            close: (dialogResult: any) => { }
          }
        },
        {
          provide: MatDialogRef,
          useValue: {
            close: (dialogResult: any) => { }
          }
        }
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadDocumentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
