import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { SendForReviewModalComponent } from "./send-for-review-modal.component";

import { MatCheckboxModule } from "@angular/material";

import { MatDialogRef } from "@angular/material";

describe("SendForReviewModalComponent", () => {
  let component: SendForReviewModalComponent;
  let fixture: ComponentFixture<SendForReviewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendForReviewModalComponent ],
      imports: [ MatCheckboxModule ],
      providers: [
        {
          provide: MatDialogRef,
          useValue: {
            close: (dialogResult: any) => { }
          }
        },
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendForReviewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
