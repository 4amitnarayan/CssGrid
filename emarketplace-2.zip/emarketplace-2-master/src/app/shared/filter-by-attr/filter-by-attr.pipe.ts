import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "filterByAttr"
})
export class FilterByAttrPipe implements PipeTransform {

  transform(items: any[], attr: string, query: string): any {
    if (!items || !query) {
      return items;
    }
    return items.filter(item => {
      if (item[attr].toLowerCase().indexOf(query.toLowerCase()) !== -1) {
        return true;
      }
      return false;
    });
  }

}
