import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CancelUploadDocumentModalComponent } from "./cancel-upload-document-modal.component";

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { MatDialogRef } from "@angular/material";

import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";

describe("CancelUploadDocumentModalComponent", () => {
  let component: CancelUploadDocumentModalComponent;
  let fixture: ComponentFixture<CancelUploadDocumentModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CancelUploadDocumentModalComponent ],
      providers: [
        {
          provide: MatDialogRef,
          useValue: {
            close: (dialogResult: any) => { }
          }
        },
        FormBuilder
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelUploadDocumentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
