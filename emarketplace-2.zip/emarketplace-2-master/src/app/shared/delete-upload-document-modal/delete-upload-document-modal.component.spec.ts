import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DeleteUploadDocumentModalComponent } from "./delete-upload-document-modal.component";

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";

describe("DeleteUploadDocumentModalComponent", () => {
  let component: DeleteUploadDocumentModalComponent;
  let fixture: ComponentFixture<DeleteUploadDocumentModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteUploadDocumentModalComponent ],
      providers: [
        {
          provide: MatDialogRef,
          useValue: {
            close: (dialogResult: any) => { }
          }
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: {}
        },
        FormBuilder
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteUploadDocumentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
