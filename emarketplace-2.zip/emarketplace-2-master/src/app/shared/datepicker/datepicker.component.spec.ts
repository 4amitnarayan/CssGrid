import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DatepickerComponent } from "./datepicker.component";

import { BsDatepickerModule, BsDatepickerConfig, ModalModule, BsLocaleService } from "ngx-bootstrap";

describe("DatepickerComponent", () => {
  let component: DatepickerComponent;
  let fixture: ComponentFixture<DatepickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatepickerComponent ],
      imports: [ BsDatepickerModule, ModalModule.forRoot() ],
      providers: [ BsDatepickerConfig, BsLocaleService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatepickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
