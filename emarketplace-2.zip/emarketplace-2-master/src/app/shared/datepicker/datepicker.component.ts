import {
  Component, ViewChild, Input, Output, EventEmitter,
  AfterViewChecked, ViewChildren, QueryList, Renderer2, OnChanges, ElementRef
} from "@angular/core";
import * as $ from "jquery";
import { isFulfilled } from "q";
@Component({
  selector: "app-datepicker",
  templateUrl: "./datepicker.component.html",
  styleUrls: ["./datepicker.component.scss"]
})
export class DatepickerComponent implements AfterViewChecked, OnChanges {
  @ViewChild("dElement") dElement;
  @ViewChild("datePickerContent") datePickerContentEl: ElementRef;
  @Output() changeDate = new EventEmitter();
  @Input() dateModel: any;
  @Input() minDate: any;
  @Input() placeholder = "Select Date";
  @Input() disabledVariable = true;
  @Output() onShow = new EventEmitter();
  private showDatepicker = false;
  bsConfig = {
    showWeekNumbers: false,
    dateDisabled: true,
    dateInputFormat: "DD MMMM YYYY"
  };
  constructor(private renderer: Renderer2) {
  }

  ngOnChanges(): void {
    if (this.minDate) {
      this.minDate = new Date(this.minDate);
    }
    if (this.dateModel) {
      this.dateModel = new Date(this.dateModel);
    }
  }

  ngAfterViewChecked() {
    // custom datepicker
    const arrayTitleDay = $("thead th");
    for (let i = 0; i < arrayTitleDay.length; i++) {
      const el = $("thead th").get(i);
      const titleWeekDay = $(el).text().trim();
      if (titleWeekDay === "Sun") {
        $(el).text("S");
      } else if (titleWeekDay === "Mon") {
        $(el).text("M");
      } else if (titleWeekDay === "Tue") {
        $(el).text("T");
      } else if (titleWeekDay === "Wed") {
        $(el).text("W");
      } else if (titleWeekDay === "Thu") {
        $(el).text("T");
      } else if (titleWeekDay === "Fri") {
        $(el).text("F");
      } else if (titleWeekDay === "Sat") {
        $(el).text("S");
      }
    }
    $("bs-datepicker-container .bs-datepicker .bs-datepicker-container .btn-close").remove();
    $("bs-datepicker-container .bs-datepicker .bs-datepicker-container").append(
      "<div class='btn-close'><a href='javascript:;'>Close</a></div>"
    );
    $(".bs-datepicker .bs-datepicker-container").on("click", ".btn-close", function () {
      $("bs-datepicker-container").addClass("hide");
      $(".datepicker-here").removeClass("active");
    });
  }
  // update limit datepicker from other component
  updateLimitValue(minDate): void {
    this.minDate = new Date(minDate);
  }
  // show datepicker
  showDatePicker(event): void {
    event.stopPropagation();
    if (this.disabledVariable) {
      this.dElement.toggle();
      $("bs-datepicker-container").removeClass("hide");
      $(event.currentTarget).addClass("active");
    }
  }

  // listen select datepicker
  onValueChange(value: Date) {
    if (value) {
      this.dateModel = value;
    }
  }

  // hidden Datepicker
  hiddenDatepicker(): void {
    this.dElement.hide();
    if (this.dateModel) {
      this.dateModel = new Date(this.dateModel);
      this.changeDate.emit((this.dateModel.getMonth() + 1) + "/"
        + this.dateModel.getDate() + "/"
        + this.dateModel.getFullYear());
    }
  }

  // listen when datepicker show/hidden
  handler(value): void {
    if (value === "onShown") {
      this.onShow.emit();
      this.datePickerContentEl.nativeElement.classList.add("active");
    } else {
      this.datePickerContentEl.nativeElement.classList.remove("active");
    }
  }
}
