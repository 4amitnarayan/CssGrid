
# EMARKET APP
---------------------------

## Authentication

user `user@user.com` and the password `12345678`.
admin `admin@admin.com` and the password `12345678`.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

  + ng test --> No error  (https://gyazo.com/0638c4bfb71aad451328a2faeb6ef967)


<!-- ////////////////    user create    //////////////////////////-->

### 1. External Dependencies

 - node js ( recommended latest stable version https://nodejs.org/en/)
 - angular 5.2.9 ( used with official angular-cli https://github.com/angular/angular-cli )
 - material.angular.io (http://material.angular.io)
 - bootstrap 3 (http://getbootstrap.com)
 - fontawesome (https://fontawesome.com/)

### 2. Components Shared
    
 - Header Component - A simple custom header component, in case if not required just remove the `<app-header>` tag from layout file app.component.html

  ```
    <app-header></app-header>
   ```
          
  
 - App Component - Application's common page layout
 
    ``` 
        <!--page header-->
        <app-header></app-header>

        <!-- router outlet, defaults to home component -->
        <router-outlet></router-outlet>

    ```

### 3. emarket material

  https://www.npmjs.com/package/emarket-material

  + install  "npm i emarket-material"

    -  import { EmarketMaterialModule } from 'emarket-material';

        @NgModule({
          imports: [
            EmarketMaterialModule
          ]
        })

    - using list module{
        MatAutocompleteModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatChipsModule,
        MatDatepickerModule,
        MatDialogModule,
        MatDividerModule,
        MatExpansionModule,
        MatFormFieldModule,
        MatGridListModule,
        MatIconModule,
        MatInputModule,
        MatListModule,
        MatMenuModule,
        MatNativeDateModule,
        MatPaginatorModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatRadioModule,
        MatRippleModule,
        MatSelectModule,
        MatSidenavModule,
        MatSliderModule,
        MatSlideToggleModule,
        MatSnackBarModule,
        MatSortModule,
        MatStepperModule,
        MatTableModule,
        MatTabsModule,
        MatToolbarModule,
        MatTooltipModule,
      }

  - checkbox custom material

  using: 
  '<app-check-box [color]="" [label]="" [label2]="" [value]="" [checkboxId]="" [link]="" (updateChecked)="updateCheckedOptions(i)" [checked]=""></app-check-box>

  . label, label2, value, checkboxId: string
  . label2: show link in checkbox, link: route link
  . color: set color checkbox checked
  . updateCheckedOptions: EventEmitter


  + file src/theme.scss  // color material

### 4. emarket router child && side nav custom matarial component

  install
  + npm i emarket-router

  // import module
  import { RouteLinkModule } from 'emarket-router';
  import { EmarketSidenavContainerModule } from 'emarket-router';

  @NgModule({
    imports: [
      RouteLinkModule, // link child component
      EmarketSidenavContainerModule // side nav component
    ]
  })

  + using
  - emarket side nav custom matarial
  <app-emarket-sidenav-container>
    <ng-content></ng-content> // user code views
  </app-emarket-sidenav-container>

  - emarket router child
  <app-route-link [links]="listRoute"></app-route-link>

  example:

  listRoute = [
    {
      "href":"/users/merchant/my-account/my-profile",
      "name":"My Profile"
    }
    ,{
      "href":"/users/merchant/my-account/merchant-detail",
      "name":"Merchant detail"
    }
    ,{
      "href":"/users/merchant/my-account/stores",
      "name":"Stores"
    }
  ]

### 5. data services

  Create services
  + folder/file: core/services/data.service.ts

  ==> using: 

  import { DataService } from '~/core/services/data.service';

  constructor(
    private dataService: DataService
  ) { }

  this.dataService.getData(' url json file ').subscribe(
    data => {
      user coding
    },
    error => user coding
  );

### 6. Pipe filter

  Create pipe
  + folder/file: shared/filter/

    ==> using:

    import { FilterPipe } from '~/shared/filter/';

    @NgModule({
      declarations: FilterPipe
    })

  + example: *ngFor="let item of items  | filter: <'user add value'>
