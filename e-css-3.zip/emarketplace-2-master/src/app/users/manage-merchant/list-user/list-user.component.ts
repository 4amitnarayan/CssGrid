import { Component, OnInit } from "@angular/core";
import { ActiveUserComponent } from "../../../shared/active-user/active-user.component";
import { MatDialog } from "@angular/material";

import { DataService } from "../../../core/services/data.service";

import { Cookie } from "ng2-cookies/ng2-cookies";
import { Router } from "@angular/router";


import * as _ from "lodash";

@Component({
  selector: "app-list-user",
  templateUrl: "./list-user.component.html",
  styleUrls: ["./list-user.component.scss"]
})
export class ListUserComponent implements OnInit {
  /**
   * The merchantJson
   */
  listUserJson: Array<any>;

  /**
   * The sumData
   */
  sumData: number;

  /**
   * The search
   */
  search: any;

  /**
   * The errorMessage
   */
  errorMessage: string;

  /**
   * The sofr data
   */
  isAscOrder: boolean;

  /**
   * The showMsAdd
   */
  showMsAdd: boolean;


  /**
   * The errorMessage
   */
  titleModel: string;

  constructor(
    private dataService: DataService,
    public dialog: MatDialog,
    public router: Router,
  ) { }

  ngOnInit() {
    this.onload();

    if (Cookie.get("addUser") === "done") {
      this.showMsAdd = true;
      setTimeout(() => {
        this.showMsAdd = false;
        Cookie.set("addUser", "not");
      }, 3000);
    }
  }

  ChangeStatus(item): void {
    const dialogRef = this.dialog.open(ActiveUserComponent, {
      width: "800px",
      autoFocus: false
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
    });
  }

  onload(): void {
    this.dataService.getData("http://localhost:3000/userList").subscribe(
      data => {
        this.listUserJson = data;

        this.sumData = this.listUserJson.length;
      },
      error => this.errorMessage = <any>error
    );
  }

  hoverUser(item: any) {
    if (item.Status === "Active") {
      item.Status = "Deactivate";
    }
  }
  outHoverUser(item: any) {
    if (item.Status === "Deactivate") {
      item.Status = "Active";
    }
  }

  goUser(name: string, role: string) {
    this.router.navigate(["users/manage-merchant/detail-user"]);

    Cookie.set("view", name);
    Cookie.set("role", role);
  }

  // sort data when click on option
  sortData(column: string) {
    this.isAscOrder = !this.isAscOrder;
    this.listUserJson = _.orderBy(this.listUserJson, [column], [this.isAscOrder ? "asc" : "desc"]);
  }

}
