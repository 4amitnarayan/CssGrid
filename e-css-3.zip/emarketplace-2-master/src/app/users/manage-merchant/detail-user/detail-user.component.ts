import { Component, OnInit } from "@angular/core";
import { Cookie } from "ng2-cookies/ng2-cookies";

// @ngrx
import { Store } from "@ngrx/store";


import { Go } from "../../../actions/router";


// reducers
import {
  getAuthenticationError,
  getAuthenticatedUser,
  isAuthenticated,
  isGetRole,
  isAuthenticationLoading,
  State
} from "../../../reducers";



@Component({
  selector: "app-detail-user",
  templateUrl: "./detail-user.component.html",
  styleUrls: ["./detail-user.component.scss"]
})
export class DetailUserComponent implements OnInit {



  /**
  * info user.
  * @type {string}
  */
  firstName: string;
  lastName: string;
  email: string;
  mobile: string;

  // change status
  isactive: boolean;

  /**
  * isView
  * @type {boolean}
  */
  public isView = false;

  /**
  * isAdd
  * @type {boolean}
  */
  public isAdd = false;

  /**
  * isEdit
  * @type {boolean}
  */
  public isEdit = false;

  constructor(
    private store: Store<State>
  ) { }

  ngOnInit() {
    if (Cookie.get("view") === "detail") {
      this.firstName = "Nguyen Van";
      this.lastName = "Cuong";
      this.email = "nvcuong1006@gmail.com";
      this.mobile = "0988404477";

      this.isView = true;

    } else if (Cookie.get("view") === "add") {
      this.firstName = "";
      this.lastName = "";
      this.email = "";
      this.mobile = "";

      this.isAdd = true;
    } else if (Cookie.get("view") === "edit") {
      this.firstName = "Nguyen Van";
      this.lastName = "Cuong";
      this.email = "nvcuong1006@gmail.com";
      this.mobile = "0988404477";

      this.isEdit = true;
    }
  }

  goBack() {
    if (Cookie.get("role") === "userPage") {
      this.store.dispatch(new Go({
        path: ["/users/manage-merchant/list-user"]
      }));
    } else if (Cookie.get("role") === "home") {
      this.store.dispatch(new Go({
        path: ["/users/manage-merchant/this-page"]
      }));
    }
  }

}
