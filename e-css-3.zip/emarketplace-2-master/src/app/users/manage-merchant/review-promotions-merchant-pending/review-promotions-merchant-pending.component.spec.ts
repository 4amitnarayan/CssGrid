import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ReviewPromotionsMerchantPendingComponent } from "./review-promotions-merchant-pending.component";

describe("ReviewPromotionsMerchantPendingComponent", () => {
  let component: ReviewPromotionsMerchantPendingComponent;
  let fixture: ComponentFixture<ReviewPromotionsMerchantPendingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewPromotionsMerchantPendingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewPromotionsMerchantPendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
