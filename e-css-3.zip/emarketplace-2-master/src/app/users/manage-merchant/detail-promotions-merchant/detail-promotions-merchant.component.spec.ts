import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DetailPromotionsMerchantComponent } from "./detail-promotions-merchant.component";

import { MatTabsModule, MatFormFieldModule, MatDialogModule } from "@angular/material"

import { FormsModule } from '@angular/forms';

import { DatepickerComponent} from '../../../shared/datepicker/datepicker.component';

import { FilterPipe } from '../../../shared/filter/index'

import { FilterByAlphaPipe } from '../../../shared/filter-by-alpha/filter-by-alpha.pipe'

import { FilterByAttrPipe } from '../../../shared/filter-by-attr/filter-by-attr.pipe'

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { BsDatepickerModule, BsDatepickerConfig, ModalModule, BsLocaleService } from 'ngx-bootstrap';

import { DataService } from '../../../core/services/data.service';

import { HttpModule } from '@angular/http';

import { ActivatedRoute } from "@angular/router";

// rxjs
import { Observable } from "rxjs/Observable";

import { RouterModule } from '@angular/router';

import {APP_BASE_HREF} from '@angular/common';

describe("DetailPromotionsMerchantComponent", () => {
  let component: DetailPromotionsMerchantComponent;
  let fixture: ComponentFixture<DetailPromotionsMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailPromotionsMerchantComponent, DatepickerComponent, FilterPipe, FilterByAlphaPipe, FilterByAttrPipe ],
      imports: [ HttpModule, MatTabsModule, FormsModule, MatFormFieldModule, BsDatepickerModule, ModalModule.forRoot(), MatDialogModule,
        RouterModule.forRoot([{
          path: "",
          component: DetailPromotionsMerchantComponent
        }])
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [ BsDatepickerConfig, BsLocaleService, DataService,
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: Observable.of({})
          }
        },
        {
          provide: APP_BASE_HREF, useValue : '/' 
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailPromotionsMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
