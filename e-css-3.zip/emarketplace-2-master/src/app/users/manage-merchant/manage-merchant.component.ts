import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

import { FormControl } from "@angular/forms";

// @ngrx
import { Store } from "@ngrx/store";



// rxjs
import { Observable } from "rxjs/Observable";

// reducers
import {
  getAuthenticatedUser,
  State
} from "../../reducers";
import { PromotionsService } from "../../core/services/promation";


@Component({
  selector: "app-manage-merchant",
  templateUrl: "./manage-merchant.component.html",
  styleUrls: ["./manage-merchant.component.scss"]
})
export class ManageMerchantComponent implements OnInit {


  mode = new FormControl("side");
  public countPendingPromotion = 0;
  // path Router
  public urlRouter: string;
  public isShowLeftNav = true;
  constructor(
    public router: Router,
    private promotionsService: PromotionsService) {
    router.events.subscribe((event: any) => {
      this.urlRouter = event.url;
      if (this.urlRouter && this.urlRouter.indexOf("/users/manage-merchant/detail-promotions-merchant") !== -1) {
        this.isShowLeftNav = false;
      } else {
        this.isShowLeftNav = true;
      }
    });
  }

  ngOnInit(): void {
    this.onload();
  }

  onload(): void {
    this.promotionsService.getNumberPromationByCategoryAdmin("pending").subscribe(result => {
      console.log(result);
      this.countPendingPromotion = result;
    });
  }
}
