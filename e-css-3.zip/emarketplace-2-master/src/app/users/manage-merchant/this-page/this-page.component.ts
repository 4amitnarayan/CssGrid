import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators, FormControl } from "@angular/forms";
import { DataService } from "../../../core/services/data.service";

import { Cookie } from "ng2-cookies/ng2-cookies";
import { Router } from "@angular/router";

import * as _ from "lodash";

@Component({
  selector: "app-this-page",
  templateUrl: "./this-page.component.html",
  styleUrls: ["./this-page.component.scss"]
})
export class ThisPageComponent implements OnInit {

  /**
   * The merchantJson
   */
  merchantJson: Array<any>;

  /**
   * The sumData
   */
  sumData: number;

  /**
   * The search
   */
  search: any;


  /**
   * The errorMessage
   */
  errorMessage: string;

  /**
   * The sortByColumn
   */
  isAscOrder: boolean;

  /**
   * The authentication form.
   * @type {FormControl}
   */
  public mode: FormControl;


  /**
   * isfocus
   * @type {boolean}
   */
  public isfocus: true;
  constructor(
    private dataService: DataService,
    private router: Router
  ) { }

  ngOnInit() {
    this.mode = new FormControl("over");

    this.onload();
  }

  onload(): void {
    this.dataService.getData("http://localhost:3000/merchantList").subscribe(
      data => {
        this.merchantJson = data;

        this.sumData = this.merchantJson.length;
      },
      error => this.errorMessage = <any>error
    );
  }

  goUser(name: string, page: string) {
    this.router.navigate(["users/manage-merchant/detail-user"]);

    Cookie.set("view", name);
    Cookie.set("role", page);
  }

  // sort data when click on option
  sortData(column: string) {
    this.isAscOrder = !this.isAscOrder;
    this.merchantJson = _.orderBy(this.merchantJson, [column], [this.isAscOrder ? "asc" : "desc"]);
  }

}
