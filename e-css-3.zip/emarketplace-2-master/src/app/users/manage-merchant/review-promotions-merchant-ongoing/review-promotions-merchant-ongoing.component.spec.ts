import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ReviewPromotionsMerchantOngoingComponent } from "./review-promotions-merchant-ongoing.component";

describe("ReviewPromotionsMerchantOngoingComponent", () => {
  let component: ReviewPromotionsMerchantOngoingComponent;
  let fixture: ComponentFixture<ReviewPromotionsMerchantOngoingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewPromotionsMerchantOngoingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewPromotionsMerchantOngoingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
