import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ReviewPromotionsMerchantPastComponent } from "./review-promotions-merchant-past.component";

describe("ReviewPromotionsMerchantPastComponent", () => {
  let component: ReviewPromotionsMerchantPastComponent;
  let fixture: ComponentFixture<ReviewPromotionsMerchantPastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReviewPromotionsMerchantPastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewPromotionsMerchantPastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
