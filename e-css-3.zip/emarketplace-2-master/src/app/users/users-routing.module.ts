import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

// guards
import { AuthenticatedGuard } from "../shared/authenticated.guard";


// components Authenticated
import { SignInComponent } from "./sign-in/sign-in.component";
import { SignUpComponent } from "./sign-up/sign-up.component";
import { ForgotUserComponent } from "./forgot-user/forgot-user.component";
import { ForgotPasswordComponent } from "./forgot-password/forgot-password.component";
import { ResetComponent } from "./reset/reset.component";

// components user view
import { MyAccountComponent } from "./my-account/my-account.component";
import { MyProfileComponent } from "./my-account/my-profile/my-profile.component";
import { MerchantDetailComponent } from "./my-account/merchant-detail/merchant-detail.component";
import { StoresComponent } from "./my-account/stores/stores.component";
import { StoreInfoComponent } from "./my-account/store-info/store-info.component";

import { CreatePromotionsMerchantComponent } from "./my-account/create-promotions-merchant/create-promotions-merchant.component";
import {
  ViewPromotionsMerchantOngoingComponent
} from "./my-account/view-promotions-merchant-ongoing/view-promotions-merchant-ongoing.component";
import {
  ViewPromotionsMerchantPendingComponent
} from "./my-account/view-promotions-merchant-pending/view-promotions-merchant-pending.component";
import { ViewPromotionsMerchantPastComponent } from "./my-account/view-promotions-merchant-past/view-promotions-merchant-past.component";



// components admin view
import { ManageMerchantComponent } from "./manage-merchant/manage-merchant.component";
import { DetailMerchantComponent } from "./manage-merchant/detail-merchant/detail-merchant.component";
import { InviteMerchantComponent } from "./invite-merchant/invite-merchant.component";
import { DetailUserComponent } from "./manage-merchant/detail-user/detail-user.component";
import { ListUserComponent } from "./manage-merchant/list-user/list-user.component";
import { ThisPageComponent } from "./manage-merchant/this-page/this-page.component";
import {
  ReviewPromotionsMerchantOngoingComponent
} from "./manage-merchant/review-promotions-merchant-ongoing/review-promotions-merchant-ongoing.component";
import {
  ReviewPromotionsMerchantPendingComponent
} from "./manage-merchant/review-promotions-merchant-pending/review-promotions-merchant-pending.component";
import {
  ReviewPromotionsMerchantPastComponent
} from "./manage-merchant/review-promotions-merchant-past/review-promotions-merchant-past.component";
import { DetailPromotionsMerchantComponent } from "./manage-merchant/detail-promotions-merchant/detail-promotions-merchant.component";

// routes
const routes: Routes = [
  {
    canActivate: [AuthenticatedGuard], // ff1 fixed reload page
    path: "my-account",
    component: MyAccountComponent,
    children: [
      {
        path: "",
        redirectTo: "my-profile",
        pathMatch: "full"
      },
      { path: "my-profile", component: MyProfileComponent },
      { path: "merchant-detail", component: MerchantDetailComponent },
      { path: "stores", component: StoresComponent },
      {
        path: "view-promotions-merchant-ongoing",
        component: ViewPromotionsMerchantOngoingComponent
      },
      {
        path: "view-promotions-merchant-pending",
        component: ViewPromotionsMerchantPendingComponent
      },
      {
        path: "view-promotions-merchant-past",
        component: ViewPromotionsMerchantPastComponent
      },
      {
        path: "create-promotions-merchant",
        component: CreatePromotionsMerchantComponent
      }
    ]
  },
  {
    canActivate: [AuthenticatedGuard], // ff1 fixed reload page
    path: "manage-merchant",
    component: ManageMerchantComponent,
    children: [
      {
        path: "",
        redirectTo: "this-page",
        pathMatch: "full"
      },
      { path: "this-page", component: ThisPageComponent },
      { path: "detail-user", component: DetailUserComponent },
      { path: "detail-merchant", component: DetailMerchantComponent },
      { path: "list-user", component: ListUserComponent },
      {
        path: "review-promotions-merchant-ongoing",
        component: ReviewPromotionsMerchantOngoingComponent
      },
      {
        path: "review-promotions-merchant-pending",
        component: ReviewPromotionsMerchantPendingComponent
      },
      {
        path: "review-promotions-merchant-past",
        component: ReviewPromotionsMerchantPastComponent
      },
      {
        path: "detail-promotions-merchant",
        component: DetailPromotionsMerchantComponent
      }
    ]
  },
  {
    canActivate: [AuthenticatedGuard], // ff1 fixed reload page
    path: "store-detail", component: StoreInfoComponent
  },
  {
    canActivate: [AuthenticatedGuard], // ff1 fixed reload page
    path: "store-detail/:idStore", component: StoreInfoComponent
  },
  {
    canActivate: [AuthenticatedGuard], // ff1 fixed reload page
    path: "invite-merchant",
    component: InviteMerchantComponent
  },
  {
    path: "sign-in",
    component: SignInComponent
  },
  {
    path: "sign-up",
    component: SignUpComponent
  },
  {
    path: "forgot-user",
    component: ForgotUserComponent
  },
  {
    path: "forgot-password",
    component: ForgotPasswordComponent
  },
  {
    path: "reset",
    component: ResetComponent
  },
  {
    path: "**",
    redirectTo: "/users/sign-up"
  }
];

@NgModule({
  exports: [
    RouterModule
  ],
  imports: [
    RouterModule.forChild(routes)
  ]
})
export class UsersRoutingModule { }
