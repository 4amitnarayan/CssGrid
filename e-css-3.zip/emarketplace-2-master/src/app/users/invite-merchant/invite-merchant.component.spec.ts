import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { InviteMerchantComponent } from "./invite-merchant.component";

import { MatAutocompleteModule } from "@angular/material";

import { HttpModule } from "@angular/http";
import { DataService } from "../../core/services/data.service";

// ngrx
import { Store, StoreModule } from "@ngrx/store";

// reducers
import { reducers } from "../../reducers";

describe("InviteMerchantComponent", () => {
  let component: InviteMerchantComponent;
  let fixture: ComponentFixture<InviteMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
        MatAutocompleteModule,
        StoreModule.forRoot(reducers)
      ],
      declarations: [InviteMerchantComponent],
      providers: [
        DataService
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InviteMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
