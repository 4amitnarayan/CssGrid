import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CreatePromotionsMerchantComponent } from "./create-promotions-merchant.component";

describe("CreatePromotionsMerchantComponent", () => {
  let component: CreatePromotionsMerchantComponent;
  let fixture: ComponentFixture<CreatePromotionsMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePromotionsMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePromotionsMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
