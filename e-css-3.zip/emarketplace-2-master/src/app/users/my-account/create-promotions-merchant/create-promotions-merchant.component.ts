import { Component, OnInit, ViewChild, HostListener } from "@angular/core";
import { DataService } from "../../../core/services/data.service";
import { FormControl, Validators } from "@angular/forms";
import { Promotion } from "../../../core/models/promotion";
import { MatDialog, MatDialogModule } from "@angular/material";
import { ExitSavingModalComponent } from "../../../shared/exit-saving-modal/exit-saving-modal.component";
import { CallbackAddPromotionModalComponent } from "../../../shared/callback-add-promotion-modal/callback-add-promotion-modal.component";
import {
  CallbackSubmitAddPromotionModalComponent
} from "../../../shared/callback-submit-add-promotion-modal/callback-submit-add-promotion-modal.component";
import { DatepickerComponent } from "../../../shared/datepicker/datepicker.component";
import { PromotionsService } from "../../../core/services/promation";
import { Router } from "@angular/router";
const HTTP_REGEX = "https?://.+";
@Component({
  selector: "app-create-promotions-merchant",
  templateUrl: "./create-promotions-merchant.component.html",
  styleUrls: ["./create-promotions-merchant.component.scss"],
  providers: [DataService]
})
export class CreatePromotionsMerchantComponent implements OnInit {
  // Promotion Create
  public promotion: Promotion = {
    "promotionId": (new Date()).getTime().toString(),
    "promotionMode": "",
    "promotionStatus": "",
    "promotionStartDate": "",
    "promotionEndDate": "",
    "promotionName": "",
    "promotionCategory": "pending",
    "promotionMerchant": "",
    "promotionDescription": "",
    "promotionUrl": "",
    "promotionEmail": [],
    "promotionTermsConditions": [],
    "promotionCountry": []
  }
  // number tab
  public numberTab = 0;
  // tab 1
  public listEmailCompany: any[] = [];
  public txtEmail: string;
  // text MS error load json
  public errorMessage: string;

  // list country
  public countries: any[] = [];
  // item contries select stores
  public promotingCountrySelected: any;
  // list sctore of promoting country
  public stores: any[];
  // list alphabetical
  public alphabetical: any[];
  // query search store
  public querySearchStore = "";
  public isOnline = false;

  public isCheckedAll = false;
  public showClearChecked = false;
  public showPopupAllStoreChecked = false;
  public showPopupCountStoreChecked = false;
  public showContentSubmit = false;

  public showBtnSubmit = true;
  public errorHttp = false;
  private httpFormControl = new FormControl("", [
    Validators.required,
    Validators.pattern(HTTP_REGEX)
  ]);
  public showTooltipsDescription = false;
  @ViewChild("dStart") dStart: DatepickerComponent;
  @ViewChild("dEnd") dEnd: DatepickerComponent;
  constructor(
    private dataService: DataService,
    private dialog: MatDialog,
    private promotionSvc: PromotionsService,
    private router: Router
  ) { }

  ngOnInit() {
    this.onload();
  }

  // on load data
  onload(): void {
    this.dataService.getData("http://localhost:3000/countries").subscribe(
      data => {
        this.countries = data || [];
        if (this.countries.length === 1) {
          this.addPromotingsCountry(this.countries[0]);
        }
      },
      error => this.errorMessage = <any>error
    );

    // get array alphabetical json
    this.dataService.getData("http://localhost:3000/alphabetical").subscribe(
      data => {
        this.alphabetical = data || [];
      },
      error => this.errorMessage = <any>error
    );
  }

  // set promotion Mode
  setOnlineOfferFunc(): void {
    this.isOnline = !this.isOnline;
    if (this.isOnline) {
      this.promotion.promotionMode = "Online";
      this.checkInputEmpty();
    } else {
      this.promotion.promotionMode = "Offine";
      this.showBtnSubmit = true;
    }
  }

  // select tab
  selectTabContent(event): void {
    this.numberTab = event.index;
  }

  // callback open start datepicker
  callbackDStartShow(): void {
    this.dEnd.hiddenDatepicker();
  }

  // callback open end datepicker
  callbackDEndShow(): void {
    this.dStart.hiddenDatepicker();
  }
  // get description store of element country selected
  getDetailStoreByCountry(country): string {
    if ( this.stores && country.stores.length > 0 && country.stores.length < this.stores.length) {
      return country.stores.length + " Stores";
    } else if (this.stores && country.stores.length === this.stores.length) {
      return "All Stores";
    } else {
      return "Select Stores";
    }
  }
  // add object promotings countries
  addPromotingsCountry(country): void {
    country.selected = true;
    country.stores = [];
    this.promotion.promotionCountry.push(country);
  }
  // select store for promoting country element
  addStoreForPromotingCountry(country): void {
    this.isCheckedAll = false;
    this.promotingCountrySelected = Object.assign({}, country);
    this.loadStoreByCountry();
    this.showPopupAllStoreChecked = false;
    this.showPopupCountStoreChecked = false;
  }
  // load store on promoting country
  loadStoreByCountry(): void {
    this.dataService.getData("http://localhost:3000/stores").subscribe(
      data => {
        this.stores = data || [];
        if (this.promotingCountrySelected.stores.length > 0) {
          for (let i = 0; i < this.stores.length; i++) {
            const store = this.stores[i];
            for (let j = 0; j < this.promotingCountrySelected.stores.length; j++) {
              const element = this.promotingCountrySelected.stores[j];
              if (store.storeId === element.storeId) {
                store.isChecked = element.isChecked;
              }
            }
          }
          this.initOnloadStore();
        }
      },
      error => this.errorMessage = <any>error
    );
  }

  // init on load store
  initOnloadStore(): void {
    this.showPopupCountStoreChecked = false;
    this.showClearChecked = false;
    this.showPopupAllStoreChecked = false;
  }
  // toggle checked store
  toggleCheckedStore(item): void {
    item.isChecked = !item.isChecked;
    this.checkAllStoreSelect();
  }
  // select all store
  selectAllStore(): void {
    this.isCheckedAll = !this.isCheckedAll;
    for (let i = 0; i < this.stores.length; i++) {
      this.stores[i].isChecked = this.isCheckedAll;
    }
    this.checkAllStoreSelect();
  }
  // check all store selected
  checkAllStoreSelect(): void {
    this.showPopupCountStoreChecked = false;
    this.showClearChecked = false;
    for (let i = 0; i < this.stores.length; i++) {
      if (this.stores[i].isChecked) {
        this.showClearChecked = true;
      } else {
        this.isCheckedAll = false;
        this.showPopupAllStoreChecked = false;
      }
    }
    // show popup when select store
    if (this.showClearChecked && !this.isCheckedAll) {
      this.showPopupCountStoreChecked = true;
    } else if (this.isCheckedAll) {
      this.showPopupAllStoreChecked = true;
    }
  }
  // count store selected
  countStoreSelected(): number {
    let temp = 0;
    for (let i = 0; i < this.stores.length; i++) {
      const element = this.stores[i];
      if (element.isChecked) {
        temp++;
      }
    }
    return temp;
  }

  // clear Store Selected
  clearStoreSeleted(): void {
    for (let i = 0; i < this.stores.length; i++) {
      this.stores[i].isChecked = false;
    }
    this.isCheckedAll = false;
    this.showClearChecked = false;
    this.showPopupAllStoreChecked = false;
  }
  // back content select valid
  backValidStoresFunc(): void {
    this.promotingCountrySelected = undefined;
  }

  // confirm select store
  confirmSelectStore(): void {
    this.promotingCountrySelected.stores = [];
    for (let i = 0; i < this.stores.length; i++) {
      const store = this.stores[i];
      if (store.isChecked) {
        this.promotingCountrySelected.stores.push(store);
      }
    }
    // update promoting country after select store
    for (let i = 0; i < this.promotion.promotionCountry.length; i++) {
      const country = this.promotion.promotionCountry[i];
      if (country.id === this.promotingCountrySelected.id) {
        this.promotion.promotionCountry[i] = Object.assign({}, this.promotingCountrySelected);
        this.promotingCountrySelected = undefined;
        return;
      }
    }
  }
  // submit
  btnSubmitFunc(): void {
    this.showContentSubmit = true;
  }

  // check input
  checkInputEmpty(): void {
    this.showBtnSubmit = false;
    this.errorHttp = this.httpFormControl.hasError("required") || this.httpFormControl.hasError("pattern");
    if (!this.errorHttp) {
      this.showBtnSubmit = true;
    }
  }
  // clear input
  clearTextInput(): void {
    this.promotion.promotionUrl = "";
    this.showBtnSubmit = false;
  }
  // cancel submit
  cancelSubmitFunc(): void {
    this.showContentSubmit = false;
  }

  // add list email
  addListEmailFunc(): void {
    if (this.txtEmail !== "") {
      this.promotion.promotionEmail.push(this.txtEmail);
    }
    this.txtEmail = "";
  }

  // delete item email
  deleteItemEmail(index): void {
    this.promotion.promotionEmail.splice(index, 1);
  }

  // callback select start date from datepicker
  callBackStartDate(value): void {
    if (value) {
      this.promotion.promotionStartDate = value;
      this.dEnd.updateLimitValue(this.promotion.promotionStartDate);
    }
  }

  // callback select start date from datepicker
  callBackEndDate(value): void {
    if (value) {
      this.promotion.promotionEndDate = value;
    }
  }

  // save draft
  btnSaveDraft(): void {
    this.promotionSvc.postPromation(this.promotion).subscribe(result => {
      this.openModalCallbackAddPromotion();
      this.router.navigate(["/users/my-account/view-promotions-merchant-pending"]);
    });
    window.scrollTo(0, 0);
  }

  // check submit data
  checkSubmitPromotion(): boolean {
    return true;
  }

  // show tooltips description
  showTooltipsDesc(): void {
    this.showTooltipsDescription = !this.showTooltipsDescription;
  }

  // hide tooltips description
  hideTooltipsDesc(): void {
    this.showTooltipsDescription = false;
  }

  // open modal exit saving
  openModalExitSaving(): void {
    const dialogRef = this.dialog.open(ExitSavingModalComponent, {
      width: "792px",
      height: "284px"
    });
  }

  // open modal callback save draf add promotion
  openModalCallbackAddPromotion(): void {
    const dialogRef = this.dialog.open(CallbackAddPromotionModalComponent, {
      hasBackdrop: false
    });
  }

  // open modal callback submit add promotion
  openModalCallbackSubmitAddPromotion(): void {
    const dialogRef = this.dialog.open(CallbackSubmitAddPromotionModalComponent, {
      hasBackdrop: false
    });
  }

  // submit create promotions
  submitCreatePromotions(): void {
    this.promotion.promotionStatus = "Pending Review";
    this.promotionSvc.postPromation(this.promotion).subscribe(result => {
      this.openModalCallbackSubmitAddPromotion();
      this.router.navigate(["/users/my-account/view-promotions-merchant-pending"]);
    });
    window.scrollTo(0, 0);
  }

  // click body
  @HostListener("document:click", ["$event"])
  onClick(): void {
    this.showTooltipsDescription = false;
  }
}
