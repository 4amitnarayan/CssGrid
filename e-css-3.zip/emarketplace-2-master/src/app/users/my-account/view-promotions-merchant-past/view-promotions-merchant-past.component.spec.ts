import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ViewPromotionsMerchantPastComponent } from "./view-promotions-merchant-past.component";

describe("ViewPromotionsMerchantPastComponent", () => {
  let component: ViewPromotionsMerchantPastComponent;
  let fixture: ComponentFixture<ViewPromotionsMerchantPastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewPromotionsMerchantPastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPromotionsMerchantPastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
