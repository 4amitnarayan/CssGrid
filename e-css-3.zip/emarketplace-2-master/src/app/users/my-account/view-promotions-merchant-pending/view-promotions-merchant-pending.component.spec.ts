import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ViewPromotionsMerchantPendingComponent } from "./view-promotions-merchant-pending.component";

describe("ViewPromotionsMerchantPendingComponent", () => {
  let component: ViewPromotionsMerchantPendingComponent;
  let fixture: ComponentFixture<ViewPromotionsMerchantPendingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewPromotionsMerchantPendingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPromotionsMerchantPendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
