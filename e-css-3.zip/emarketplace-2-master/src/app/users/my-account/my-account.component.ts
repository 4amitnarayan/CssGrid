import { Component, OnInit } from "@angular/core";
import { FormControl } from "@angular/forms";

// @ngrx
import { Store } from "@ngrx/store";



// rxjs
import { Observable } from "rxjs/Observable";

// reducers
import {
  getAuthenticatedUser,
  State
} from "../../reducers";

// models
import { User } from "../../core/models/user";
import { Router } from "@angular/router";
import { PromotionsService } from "../../core/services/promation";

/**
 * The user"s account.
 * @class MyAccountComponent
 */
@Component({
  selector: "app-my-account",
  templateUrl: "./my-account.component.html",
  styleUrls: ["./my-account.component.scss"]
})
export class MyAccountComponent implements OnInit {

  mode = new FormControl("side");
  public countPendingPromotion = 0;

  // the authenticated user
  public user: Observable<User>;
  // path Router
  public urlRouter: string;
  /**
   * @constructor
   */
  constructor(
    private store: Store<State>,
    public router: Router,
    private promotionsService: PromotionsService) {
    router.events.subscribe((event: any) => {
      console.log(event.url);
      this.urlRouter = event.url
      this.onload();
    });
  }

  /**
   * Lifecycle hook that is called after data-bound properties of a directive are initialized.
   * @method ngOnInit
   */
  public ngOnInit() {
    // get authenticated user
    this.user = this.store.select(getAuthenticatedUser);
    this.onload();
  }

  onload(): void {
    this.promotionsService.getNumberPromationByCategory("pending").subscribe(result => {
      this.countPendingPromotion = result;
    });
  }

}
