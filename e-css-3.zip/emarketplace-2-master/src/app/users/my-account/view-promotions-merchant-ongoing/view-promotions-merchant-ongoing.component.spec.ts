import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ViewPromotionsMerchantOngoingComponent } from "./view-promotions-merchant-ongoing.component";

describe("ViewPromotionsMerchantOngoingComponent", () => {
  let component: ViewPromotionsMerchantOngoingComponent;
  let fixture: ComponentFixture<ViewPromotionsMerchantOngoingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewPromotionsMerchantOngoingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPromotionsMerchantOngoingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
