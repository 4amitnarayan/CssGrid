import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { ExitSavingModalComponent } from "./exit-saving-modal.component";

import { RouterModule } from '@angular/router';

import {APP_BASE_HREF} from '@angular/common';

import { MatDialogRef } from "@angular/material";

describe("ExitSavingModalComponent", () => {
  let component: ExitSavingModalComponent;
  let fixture: ComponentFixture<ExitSavingModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExitSavingModalComponent ],
      imports: [RouterModule.forRoot([{
        path: "",
        component: ExitSavingModalComponent
      }])],
      providers: [
        {
          provide: APP_BASE_HREF, useValue : '/' 
        },
        {
          provide: MatDialogRef,
          useValue: {
            close: (dialogResult: any) => { }
          }
        }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExitSavingModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
