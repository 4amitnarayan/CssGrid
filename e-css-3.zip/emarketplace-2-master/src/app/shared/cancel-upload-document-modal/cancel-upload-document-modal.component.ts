import { Component, OnInit, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: "app-cancel-upload-document-modal",
  templateUrl: "./cancel-upload-document-modal.component.html",
  styleUrls: ["./cancel-upload-document-modal.component.scss"]
})
export class CancelUploadDocumentModalComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<CancelUploadDocumentModalComponent>
  ) { }

  ngOnInit() {
  }

  // cancel dialog
  cancelDialog(): void {
    this.dialogRef.close();
  }

  // close dialog
  closeDialog(): void {
    this.dialogRef.close("close");
  }

}
