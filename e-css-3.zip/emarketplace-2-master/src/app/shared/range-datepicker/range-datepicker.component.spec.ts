import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { RangeDatepickerComponent } from "./range-datepicker.component";

import { BsDatepickerModule, BsDaterangepickerConfig, ModalModule, BsLocaleService } from 'ngx-bootstrap';

describe("RangeDatepickerComponent", () => {
  let component: RangeDatepickerComponent;
  let fixture: ComponentFixture<RangeDatepickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RangeDatepickerComponent ],
      imports: [ BsDatepickerModule.forRoot(), ModalModule.forRoot() ],
      providers: [ BsDaterangepickerConfig, BsLocaleService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RangeDatepickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
