import { Component, OnInit, ViewChild, AfterViewChecked, Input, Output, EventEmitter } from "@angular/core";
import { BsDatepickerDirective } from "ngx-bootstrap/datepicker";
import * as $ from "jquery";
@Component({
  selector: "app-range-datepicker",
  templateUrl: "./range-datepicker.component.html",
  styleUrls: ["./range-datepicker.component.scss"]
})
export class RangeDatepickerComponent implements AfterViewChecked {
  @ViewChild("dp") dpEl: BsDatepickerDirective;
  @Input() showDatepicker;
  @Output() callback = new EventEmitter();
  constructor() { }

  ngAfterViewChecked(): void {
    if (this.showDatepicker) {
      this.dpEl.show();
      const element = $(".bs-datepicker-multiple").get(1);
      if (element) {
        $(element).addClass("hide");
      }
      $(".bs-datepicker-multiple .next").css("visibility", "visible");

      $("thead th:first-child").addClass("hide");
      $("tbody td:first-child").addClass("hide");
      const arrayTitleDay = $("thead th");
      for (let i = 0; i < arrayTitleDay.length; i++) {
        const el = $("thead th").get(i);
        const titleWeekDay = $(el).text().trim();
        if (titleWeekDay === "Sun") {
          $(el).text("S");
        } else if (titleWeekDay === "Mon") {
          $(el).text("M");
        } else if (titleWeekDay === "Tue") {
          $(el).text("T");
        } else if (titleWeekDay === "Wed") {
          $(el).text("W");
        } else if (titleWeekDay === "Thu") {
          $(el).text("T");
        } else if (titleWeekDay === "Fri") {
          $(el).text("F");
        } else if (titleWeekDay === "Sat") {
          $(el).text("S");
        }
      }
    } else {
      this.dpEl.hide();
    }
  }

  hiddenRangerDatepicker(): void {
    this.showDatepicker = false;
  }

  showRangerDatepicker(): void {
    this.showDatepicker = true;
  }

  // listen on change value
  onValueChange(event): void {
    if (event) {
      this.callback.emit({
        "startDate": event[0],
        "endDate": event[1]
      });
    }

  }

  // reset value 
  resetValue(): void {
    this.dpEl.bsValue = undefined;
  }

  // reset value 
  setToDateForCalendar(): void {
    this.dpEl.bsValue = new Date();
  }

}
