import { Component } from "@angular/core";
import { MatDialogRef } from "@angular/material";

@Component({
  selector: "app-send-for-review-modal",
  templateUrl: "./send-for-review-modal.component.html",
  styleUrls: ["./send-for-review-modal.component.scss"]
})
export class SendForReviewModalComponent {

  constructor(private dialogRef: MatDialogRef<SendForReviewModalComponent>) { }

  // close dialog
  closeDialog(): void {
    this.dialogRef.close();
  }

  // submit dialog
  submitDialog(): void {
    this.dialogRef.close("submit");
  }
}
