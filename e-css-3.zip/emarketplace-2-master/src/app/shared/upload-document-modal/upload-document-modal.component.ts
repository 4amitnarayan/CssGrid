import { Component } from "@angular/core";
import { MatDialogRef, MatDialog } from "@angular/material";
import { FileUploader, FileItem } from "ng2-file-upload";
import { DeleteUploadDocumentModalComponent } from "../delete-upload-document-modal/delete-upload-document-modal.component";
import { CancelUploadDocumentModalComponent } from "../cancel-upload-document-modal/cancel-upload-document-modal.component";
import * as $ from "jquery";

@Component({
  selector: "app-upload-document-modal",
  templateUrl: "./upload-document-modal.component.html",
  styleUrls: ["./upload-document-modal.component.scss"]
})
export class UploadDocumentModalComponent {
  private URL = "https://evening-anchorage-3159.herokuapp.com/api/";
  public uploaderDocuments: FileUploader = new FileUploader({ url: this.URL });
  public hasBaseDropZoneOver = false;
  public hasAnotherDropZoneOver = false;
  private fileAdd: FileItem;
  private textFile: any;
  public showError = false;
  constructor(
    private dialog: MatDialog,
    private dialogRef: MatDialogRef<UploadDocumentModalComponent>
  ) {

  }

  // file over base
  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  // select file
  selectFileFunc(event: any): void {
    $(event.target).parent().parent().find("input").click();
  }

  // next upload
  nextUploadDocument(): void {
    if (this.uploaderDocuments.queue.length === 0) {
      this.showError = true;
    } else {
      this.showError = false;
      this.dialogRef.close("next");
    }
  }

  // open modal delete file upload
  openModalDeleteFileUpload(item): void {
    const dialogRef = this.dialog.open(DeleteUploadDocumentModalComponent, {
      data: item,
    });
    dialogRef.afterClosed().subscribe(result => {
      if (typeof result !== "undefined") {
        result.remove();
      }
    });
  }

  // open modal delete upload document
  closeDialog(): void {
    const dialogRef = this.dialog.open(CancelUploadDocumentModalComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result === "close") {
        this.dialogRef.close();
      }
    });
  }
}
