import { Component, OnInit, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: "app-delete-upload-document-modal",
  templateUrl: "./delete-upload-document-modal.component.html",
  styleUrls: ["./delete-upload-document-modal.component.scss"]
})
export class DeleteUploadDocumentModalComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<DeleteUploadDocumentModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
  }

  // close dialog
  closeDialog(): void {
    this.dialogRef.close();
  }

  // delete
  deleteDialog(): void {
    this.dialogRef.close(this.data);
  }

}
