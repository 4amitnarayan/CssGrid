import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "filterByAlpha"
})
export class FilterByAlphaPipe implements PipeTransform {
  transform(items: any[], attr: string, alpha: string, query: string): any {
    if (!items || !alpha) {
      return items;
    }
    return items = items.filter(item => {
      if (item[attr].substring(0, 1).toLowerCase() === alpha.toLowerCase()
        && item[attr].toLowerCase().indexOf(query.toLowerCase()) !== -1) {
        return true;
      }
      return false;
    });
  }
}
