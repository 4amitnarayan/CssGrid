import { Component, OnInit, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: "app-delete-pending-promotion-modal",
  templateUrl: "./delete-pending-promotion-modal.component.html",
  styleUrls: ["./delete-pending-promotion-modal.component.scss"]
})
export class DeletePendingPromotionModalComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<DeletePendingPromotionModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

  }

  ngOnInit() {
  }

  // close dialog
  closeDialog(): void {
    this.dialogRef.close();
  }

  // confirm
  confirmDialog(): void {
    console.log(this.data)
    this.dialogRef.close(this.data.index);
  }

}
