import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DeletePendingPromotionModalComponent } from "./delete-pending-promotion-modal.component";

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";

describe("DeletePendingPromotionModalComponent", () => {
  let component: DeletePendingPromotionModalComponent;
  let fixture: ComponentFixture<DeletePendingPromotionModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeletePendingPromotionModalComponent ],
      providers: [
        {
          provide: MatDialogRef,
          useValue: {
            close: (dialogResult: any) => { }
          }
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: {}
        },
        FormBuilder
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletePendingPromotionModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
