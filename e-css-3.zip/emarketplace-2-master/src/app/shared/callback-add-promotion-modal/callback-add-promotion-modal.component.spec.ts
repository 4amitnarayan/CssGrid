import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CallbackAddPromotionModalComponent } from "./callback-add-promotion-modal.component";

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

import { MatDialogRef } from "@angular/material";

import { FormGroup, FormBuilder, FormControl, Validators } from "@angular/forms";

describe("CallbackAddPromotionModalComponent", () => {
  let component: CallbackAddPromotionModalComponent;
  let fixture: ComponentFixture<CallbackAddPromotionModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CallbackAddPromotionModalComponent ],
      providers: [
        {
          provide: MatDialogRef,
          useValue: {
            close: (dialogResult: any) => { }
          }
        },
        FormBuilder
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallbackAddPromotionModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
