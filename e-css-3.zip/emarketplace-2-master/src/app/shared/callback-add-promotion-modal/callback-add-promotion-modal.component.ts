import { Component } from "@angular/core";
import { MatDialogRef } from "@angular/material";
@Component({
  selector: "app-callback-add-promotion-modal",
  templateUrl: "./callback-add-promotion-modal.component.html",
  styleUrls: ["./callback-add-promotion-modal.component.scss"]
})
export class CallbackAddPromotionModalComponent {

  constructor(public dialogRef: MatDialogRef<CallbackAddPromotionModalComponent>) {
    setTimeout(() => {
      this.dialogRef.close();
    }, 10000);
  }

}
