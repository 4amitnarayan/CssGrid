export class User {
  _id?: string;
  userId?: string;
  password?: string;
  passwordconfirm?: string;
}
