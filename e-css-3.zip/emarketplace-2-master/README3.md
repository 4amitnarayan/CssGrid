# EMarket 

## Authentication

user `user@user.com` and the password `12345678`.
admin `admin@admin.com` and the password `12345678`.

## JSON mock server

+ Run `sudo npm install -g json-server` for MacOS, ` npm install -g json-server` for Windows
+ Run `npm run mock:server` for running mock server

## Flow

+ For Merchant view promotions, Merchant create promotions please login as user. For creating promtion, click 'New Promotion'
+ For Review Promotions, please login as admin and go to 'pending' tab, click on each item on the right table will go to review promotion page.


## Show empty promotion page

In order to show empty in view promotion page, please set showEmptyPromotion to true in assets/data/config.json
## Code structure

+ Folder app contains source code
+ Folder asset contains mock json data, icons, images

## Libraries
+ ng2-file-upload, MIT license, https://github.com/valor-software/ng2-file-upload
+ ngx-bootstrap, MIT license, https://github.com/valor-software/ngx-bootstrap


## install json-server
+ npm install -g json-server
+ npm run mock:server