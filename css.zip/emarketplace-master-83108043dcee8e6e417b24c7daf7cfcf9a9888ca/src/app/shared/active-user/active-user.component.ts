import { Component, OnInit, Input } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-active-user',
  templateUrl: './active-user.component.html',
  styleUrls: ['./active-user.component.scss']
})
export class ActiveUserComponent implements OnInit {

  @Input() titleModel: string;

  // titleModel: string;

  constructor(
    public dialogRef: MatDialogRef<ActiveUserComponent>
    ) { }

  ngOnInit() {
    // this.titleModel = this.setTitle;
  }
  onCloseCancel(){
    this.dialogRef.close();
  }
}
