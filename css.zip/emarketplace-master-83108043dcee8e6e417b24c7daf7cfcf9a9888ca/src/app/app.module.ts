import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpModule } from '@angular/http';
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { RouterModule } from '@angular/router';


// @ngrx
import { EffectsModule } from "@ngrx/effects";
import { StoreRouterConnectingModule, RouterStateSerializer } from "@ngrx/router-store";
import { StoreModule } from "@ngrx/store";

import { RouterEffects } from "./effects/router";
import { CustomRouterStateSerializer } from './shared/utils';


// routing
import { AppRoutingModule } from "./app-routing.module";

// components
import { AppComponent } from "./app.component";

// effects
import { UserEffects } from "./users/users.effects";

// guards
import { AuthenticatedGuard} from "./shared/authenticated.guard";

// reducers
import { metaReducers, reducers } from "./reducers";

// services
import { UserService } from "./core/services/user.service";
import { DataService } from './core/services/data.service';

import { routes } from './app-routing.module';

import 'hammerjs';

// Emarket Material Module
import { EmarketMaterialModule } from 'emarket-material';


import { HeaderComponent } from './shared/header/header.component';
import { MyProfileComponent } from "./users/my-account/my-profile/my-profile.component";
import { MerchantDetailComponent } from "./users/my-account/merchant-detail/merchant-detail.component";
import { StoresComponent } from "./users/my-account/stores/stores.component";
import { ChangePassModalViewComponent } from './shared/changepassmodalview/changepassmodalview.component';
import { ActiveUserComponent } from './shared/active-user/active-user.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ChangePassModalViewComponent,
    ActiveUserComponent
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    FormsModule,
    HttpModule,
    EmarketMaterialModule,  // EmarketMaterialModule
    AppRoutingModule,
    ReactiveFormsModule,
    EffectsModule.forRoot([
      RouterEffects,
      UserEffects
    ]),
    StoreModule.forRoot(reducers, { metaReducers }),
    StoreRouterConnectingModule.forRoot({
      /*
        They stateKey defines the name of the state used by the router-store reducer.
        This matches the key defined in the map of reducers
      */
      stateKey: 'router',
    })   
  ],
  providers: [
    DataService,
    AuthenticatedGuard,
    UserService,
    { provide: RouterStateSerializer, useClass: CustomRouterStateSerializer }
  ],
  entryComponents:[
    ChangePassModalViewComponent,
    ActiveUserComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
