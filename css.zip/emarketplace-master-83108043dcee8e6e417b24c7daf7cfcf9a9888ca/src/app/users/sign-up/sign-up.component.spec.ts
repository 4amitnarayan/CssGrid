/* tslint:disable:no-unused-variable */
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed, async } from "@angular/core/testing";
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { By } from "@angular/platform-browser";

// rxjs
import { Observable } from "rxjs/Observable";

import { HttpModule } from '@angular/http';

// ngrx
import { Store, StoreModule } from "@ngrx/store";

import { Go } from "../../actions/router";

// reducers
import { reducers } from "../../reducers";

// services
import { DataService } from '../../core/services/data.service';
import { MOCK_USER } from "../../core/services/user.service";

// models
import { User } from "../../core/models/user";

// component to test
import { SignUpComponent } from "./sign-up.component";

describe("Component: Signup", () => {
  let component: SignUpComponent;
  let fixture: ComponentFixture<SignUpComponent>;
  let page: Page;
  let user: User = new User();

  beforeEach(() => {
    user = MOCK_USER;
  });

  beforeEach(async(() => {
    // refine the test module by declaring the test component
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        HttpModule,
        ReactiveFormsModule,
        StoreModule.forRoot(reducers)
      ],
      declarations: [
        SignUpComponent
      ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            queryParams: Observable.of({})
          }
        },
        DataService
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
    .compileComponents();

    // create component and test fixture
    fixture = TestBed.createComponent(SignUpComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
  }));

  beforeEach(() => {
    // create page
    page = new Page(component, fixture);
    fixture.whenStable().then(() => {
      page.addPageElements();
    });
  });

  it("should create a FormGroup comprised of FormControls", () => {
    fixture.detectChanges();
    expect(component.signupForm instanceof FormGroup).toBe(true);
  });

  it("should authenticate", () => {
    fixture.detectChanges();

    // set FormControl values
    component.signupForm.controls["userId"].setValue(user.userId);
    component.signupForm.controls["password"].setValue(user.password);
    component.signupForm.controls["passwordconfirm"].setValue(user.passwordconfirm);

    // submit form
    component.submit();

    // verify Store.dispatch is invoked
    // expect(page.navigateSpy.calls.any()).toBe(true, "Store.dispatch not called");
  });
});

/**
 * I represent the DOM elements and attach spies.
 *
 * @class Page
 */
class Page {

  public userIdInput: HTMLInputElement;
  public navigateSpy: jasmine.Spy;
  public passwordInput: HTMLInputElement;
  public passwordConfirmInput: HTMLInputElement;

  constructor(private component: SignUpComponent, private fixture: ComponentFixture<SignUpComponent>) {
    // ese component"s injector to get services
    const injector = fixture.debugElement.injector;
    const store = injector.get(Store);

    // add spies
    // this.navigateSpy  = spyOn(store, "dispatch");
  }

  public addPageElements() {
    const userIdInputSelector = "input[formcontrolname=\"userId\"]";
    this.userIdInput = this.fixture.debugElement.query(By.css(userIdInputSelector)).nativeElement;

    const passwordInputSelector = "input[formcontrolname=\"password\"]";
    this.passwordInput = this.fixture.debugElement.query(By.css(passwordInputSelector)).nativeElement;
    
    const passwordConfirmInputSelector = "input[formcontrolname=\"passwordconfirm\"]";
    this.passwordConfirmInput = this.fixture.debugElement.query(By.css(passwordConfirmInputSelector)).nativeElement;
  }
}
