import { Component, OnInit } from '@angular/core';
import { DataService } from '../../../core/services/data.service';

@Component({
  selector: 'app-merchant-detail',
  templateUrl: './merchant-detail.component.html',
  styleUrls: ['./merchant-detail.component.scss'],
  providers:[DataService]
})
export class MerchantDetailComponent implements OnInit {

  // change view  and update merchant details
  isMerchantdetailsViewShow = true;
  // list merchant categories
  categories: any[] = [];
  countries: any[] = [];
  cities: any[] = [];
  // merchant details
  merchant: any = {};
  items: any = {};

  // text MS error load json
  errorMessage: string;  

  constructor(
    private dataService: DataService
  ) { }

  ngOnInit() {
    this.onload();
  }

  onload(): void {
    this.dataService.getData('assets/data/merchantdata.json').subscribe(
      data => {
        this.merchant = data.merchant;
        this.categories = data.categories;
      },
      error => this.errorMessage = <any>error
    );
    this.dataService.getData('assets/data/country.json').subscribe(
      data => {
        this.countries = data.countries || [];
        this.cities = this.countries[0].cities || [];
      },
      error => this.errorMessage = <any>error
    );

    this.items = ['restaurantico','bar','hotel','travelico','shop','life'];

    
  }

  changeViewUpdateMerchant() {
    this.isMerchantdetailsViewShow = !this.isMerchantdetailsViewShow;  
  }

  updateMerchant() {
    this.isMerchantdetailsViewShow = !this.isMerchantdetailsViewShow;
  }
  

  updateCheckedOptions(index) {
    this.categories[index].checked = !this.categories[index].checked;
  }

}
