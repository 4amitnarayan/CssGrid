import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { MatDialogRef, MatDialog } from '@angular/material';
import { ListUserComponent } from './list-user.component';

import { HttpModule } from '@angular/http';
import { DataService } from '../../../core/services/data.service';
import { RouterTestingModule } from '@angular/router/testing';

import { FilterPipe } from '../../../shared/filter/';

describe('ListUserComponent', () => {
  let component: ListUserComponent;
  let fixture: ComponentFixture<ListUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListUserComponent, FilterPipe ],
      imports: [
        HttpModule,
        RouterTestingModule
      ],
      providers:[
        {
          provide: MatDialog,
          useValue: {close: (dialogResult: any) => {}}
        },
        DataService
      ],
      schemas: [ NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
