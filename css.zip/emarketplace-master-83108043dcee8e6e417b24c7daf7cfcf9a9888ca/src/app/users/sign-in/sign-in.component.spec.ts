/* tslint:disable:no-unused-variable */
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement, NO_ERRORS_SCHEMA } from "@angular/core";
import { ComponentFixture, TestBed, async } from "@angular/core/testing";
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { By } from "@angular/platform-browser";
import { Store, StoreModule } from "@ngrx/store";
import { Go } from "../../actions/router";

import { DataService } from '../../core/services/data.service';
import { HttpModule } from '@angular/http';

// reducers
import { reducers } from "../../reducers";

// models
import { User } from "../../core/models/user";

// services
import { MOCK_USER } from "../../core/services/user.service";

// this component to test
import { SignInComponent } from "./sign-in.component";

describe("SignInComponent", () => {

  let component: SignInComponent;
  let fixture: ComponentFixture<SignInComponent>;
  let page: Page;
  let user: User = new User();

  beforeEach(() => {
    user = MOCK_USER;
  });

  beforeEach(async(() => {
    // refine the test module by declaring the test component
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        StoreModule.forRoot(reducers)
      ],
      declarations: [
        SignInComponent
      ],
      providers:[
        DataService
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
    .compileComponents();

    // create component and test fixture
    fixture = TestBed.createComponent(SignInComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
  }));

  beforeEach(() => {
    // create page
    page = new Page(component, fixture);

    // verify the fixture is stable (no pending tasks)
    fixture.whenStable().then(() => {
      page.addPageElements();
    });
  });

  it("should create a FormGroup comprised of FormControls", () => {
    fixture.detectChanges();
    expect(component.form instanceof FormGroup).toBe(true);
  });

  it("should authenticate", () => {
    fixture.detectChanges();

    // set FormControl values
    component.form.controls["userId"].setValue(user.userId);
    component.form.controls["password"].setValue(user.password);

    // submit form
    component.submit();

  });
});

/**
 * I represent the DOM elements and attach spies.
 *
 * @class Page
 */
class Page {

  public userIdInput: HTMLInputElement;
  public navigateSpy: jasmine.Spy;
  public passwordInput: HTMLInputElement;

  constructor(private component: SignInComponent, private fixture: ComponentFixture<SignInComponent>) {
    // use injector to get services
    const injector = fixture.debugElement.injector;
    const store = injector.get(Store);

  }

  public addPageElements() {
    const userIdInputSelector = "input[formcontrolname=\"userId\"]";
    this.userIdInput = this.fixture.debugElement.query(By.css(userIdInputSelector)).nativeElement;

    const passwordInputSelector = "input[formcontrolname=\"password\"]";
    this.passwordInput = this.fixture.debugElement.query(By.css(passwordInputSelector)).nativeElement;
  }
}
